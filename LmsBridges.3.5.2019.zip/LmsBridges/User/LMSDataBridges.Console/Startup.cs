﻿using System.IO;
//using Byui.AppSecrets.Business;
using Byui.LMSDataBridges.Business.Utilities;
using Byui.LMSDataBridges.Enterprise.Configuration;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Byui.LMSDataBridges.Console
{
    public class Startup
    {
        private readonly bool _decryptSecrets;
        private readonly IConfigurationRoot _config;
        private readonly ServiceCollection _services;
        public ServiceProvider ServiceProvider { get; private set; }
        public Startup()
        {
            _decryptSecrets = File.Exists("secrets.json");

            var builder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();
            //HACK: added true so it would use UserSecrets file.
            if (true || _decryptSecrets)
            {
                builder.AddUserSecrets<Program>();
            }

            _config = builder.Build();
            _services = new ServiceCollection();
        }
        public void ConfigureServices()
        {
            AppSettings appSettings;
            //if (_decryptSecrets)
            //{
            //    appSettings = Cryptor.DecryptFile<AppSettings>(_config["CertThumb"]);
            //    appSettings.SoaDomain = "soa.byui.edu";
            //}
            //else
            //{
                appSettings = new AppSettings
                {
                    LmsDataClientId = _config["Wso2AppKey"],
                    LmsDataClientSecret = _config["Wso2AppSecret"],
                    ApiBaseUrl = _config["AppSettings:LmsDataApiBaseUrl"],
                    BridgeMonitoringApiUrl = _config["AppSettings:BridgeMonitoringApiUrl"],
                    ServiceUser = _config["ServiceUser"],
                    ServicePassword = _config["ServicePassword"],
                    SoaDomain = _config["SoaDomain"],
                    ServiceDomain = _config["ServiceDomain"],
                    CanvasToken = _config["CanvasToken"]
                };
            //}
            _config.GetSection("AppSettings").Bind(appSettings);
            _services.AddSingleton(appSettings);

            IServiceConfiguration configuration = new ServiceConfiguration(
                "",
                appSettings.LmsDataClientId,
                appSettings.LmsDataClientSecret,
                appSettings.ApiBaseUrl,
                appSettings.BridgeMonitoringApiUrl,
                appSettings.ServiceUser,
                appSettings.ServicePassword,
                appSettings.SoaDomain,
                appSettings.CanvasToken,
                appSettings.ServiceDomain,
                120
                );

            _services.AddSingleton(configuration);

            // configure automapper
            Configuration.Configure(_services,configuration);
            ServiceProvider = _services.BuildServiceProvider();
        }
    }
}