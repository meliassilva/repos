﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BridgeMonioring.Client;
using Byui.BridgeMonitoring.Enterprise.Models;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;
using Byui.LMSDataBridges.Business.Business;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;

namespace Byui.LMSDataBridges.Console
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            // initialize dependancy injection and user secrets
            Startup startup = new Startup();
            startup.ConfigureServices();


            LoggingClient logger = startup.ServiceProvider.GetService<LoggingClient>();
            //User Bridge
            if (args.Contains("USER"))
            {
                var userBridge = startup.ServiceProvider.GetService<UserBridgeBusiness>();
                await userBridge.RunBridge();
            }
            //Student Enrollments Bridge (SEB)
            if (args.Contains("SEB"))
            {
                var runNumber = args.FirstOrDefault(arg => arg != "SEB");

                //var logTask = logger.BridgeRunStart(info);

                var studentEnrollments = startup.ServiceProvider.GetService<StudentBusiness>();
                Response<LmsData.CommonObjects.ChangeReport<Enrollment>> bridgeResponse = await studentEnrollments.RunBridge(runNumber,logger);

                //Task[] taskList = new Task[1];
                //taskList[0] = logTask;
                //Task.WaitAll(taskList);

            }
            if (args.Contains("INST"))
            {
                int runNumber = Convert.ToInt32(args.FirstOrDefault(x => int.TryParse(x, out int n)));
                var studentEnrollments = startup.ServiceProvider.GetService<StudentBusiness>();
                await studentEnrollments.SyncInstructors(runNumber);
            }
            if (args.Contains("EBCONF"))
            {
                int numberOfRuns = Convert.ToInt32(args.FirstOrDefault(x => int.TryParse(x, out int n)));
                var studentEnrollments = startup.ServiceProvider.GetService<StudentBusiness>();
                await studentEnrollments.ConfigureSectionLists(numberOfRuns);
            }
            ////Devotional Enrollments Bridge (DEB)
            if (args.Contains("DEV"))
            {
                var devotionalEnrollments = startup.ServiceProvider.GetService<DevotionalBusiness>();
                await devotionalEnrollments.RunBridge();
            }
            //Teacher Enrollments Bridge (TEB)
            if (args.Contains("TEB"))
            {
                var teacherEnrollments = startup.ServiceProvider.GetService<TeacherBusiness>();
                await teacherEnrollments.RunBridge();
            }
            ////Employee Enrollment Bridge (ECB)
            //var employeeBridge = startup.ServiceProvider.GetService<EmployeeBusiness>();
            //await employeeBridge.RunBridge();

        }


    }
}
