﻿namespace Byui.LMSDataBridges.Console
{
    /// <summary>
    /// 
    /// </summary>
    public class AppSettings
    {
        /// <summary>
        /// ServiceUser
        /// </summary>
        public string LmsDataClientId { get; set;}

        /// <summary>
        /// ServicePassword
        /// </summary>
        public string LmsDataClientSecret { get; set; }
        public string ApiBaseUrl { get; set; }
        public string ServicePassword { get; set; }
        
        public string ServiceUser { get; set; }

        public string SoaDomain { get; set; }

        public string ServiceDomain { get; set; }
        public string CanvasToken { get; set; }

        public string BridgeMonitoringApiUrl { get; set; }

        /// <summary>
        /// MetadataAddress
        /// </summary>
    }
}
