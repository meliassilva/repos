﻿using Byui.LmsData.CommonObjects;
using System.Collections.Generic;
using System.Linq;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LmsClients.LmsDataClient.Tools
{
    internal static class Converter
    {
        public static Response<ChangeReport<T>> Convert<T>(Dictionary<string, Response<ChangeReport<T>>> response)
        {
            var result = new Response<ChangeReport<T>>();

            foreach (KeyValuePair<string, Response<ChangeReport<T>>> pair in response)
            {
                Response<ChangeReport<T>> value = pair.Value;

                if (value.Data != null)
                {
                    if (result.Data == null)
                    {
                        result.Data = new ChangeReport<T>();
                    }

                    if (value.Data.Added.Count != 0)
                    {
                        if (result.Data.Added == null)
                        {
                            result.Data.Added = new List<T>();
                        }
                        result.Data.Added.AddRange(value.Data.Added);
                    }

                    if (value.Data.Updated.Count != 0)
                    {
                        if (result.Data.Updated == null)
                        {
                            result.Data.Updated = new List<Change<T>>();
                        }
                        result.Data.Updated.AddRange(value.Data.Updated);
                    }

                    if (value.Data.Deleted.Count != 0)
                    {
                        if (result.Data.Deleted == null)
                        {
                            result.Data.Deleted = new List<T>();
                        }
                        result.Data.Deleted.AddRange(value.Data.Deleted);
                    }
                }

                if (value.Errors != null)
                {
                    if (result.Errors == null)
                    {
                        result.Errors = new List<string>();
                    }
                    result.Errors.AddRange(value.Errors);
                }
            }

            return result;
        }

        public static Response<List<T>> Convert<T>(Dictionary<string, Response<List<T>>> response)
        {
            var result = new Response<List<T>>();

            foreach (KeyValuePair<string, Response<List<T>>> pair in response)
            {
                Response<List<T>> value = pair.Value;
                if (value.Data != null)
                {
                    if (result.Data == null)
                    {
                        result.Data = new List<T>();
                    }
                    result.Data.AddRange(value.Data);
                }

                if (value.Errors != null)
                {
                    if (result.Errors == null)
                    {
                        result.Errors = new List<string>();
                    }
                    result.Errors.AddRange(value.Errors);
                }
            }

            return result;
        }

        public static Response<List<T>> Convert<T>(Dictionary<string, Response<T>> response)
        {
            var result = new Response<List<T>>();

            foreach (KeyValuePair<string, Response<T>> pair in response)
            {
                Response<T> value = pair.Value;
                if (value.Data != null)
                {
                    if (result.Data == null)
                    {
                        result.Data = new List<T>();
                    }
                    result.Data.Add(value.Data);
                }

                if (value.Errors != null)
                {
                    if (result.Errors == null)
                    {
                        result.Errors = new List<string>();
                    }
                    result.Errors.AddRange(value.Errors);
                }
            }

            return result;
        }

        public static List<SectionDetails> ConvertEntityListToSectionDetailsList(List<Entity> entites)
        {
            //TODO we may need more fields here...
            return entites.Select(entity => new SectionDetails
            {
                EntityCode = entity.EntityCode,
                SystemName = entity.SystemName,
                SystemEntityId = entity.SystemEntityId,
                Name = entity.Name
            }).ToList();
        }
    }
}
