﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Byui.LmsClients.LmsDataClient.Tools;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LmsClients.LmsDataClient.Clients
{
    internal class AssignmentsClient
    {
        private readonly ApiClient _client;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="apiClient"></param>
        public AssignmentsClient(ApiClient apiClient)
        {
            _client = apiClient;
        }

        /// <summary>
        /// Get enrollments from entity
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Assignments>>> GetLmsAssignmentsFromEntity(string entityCode) => Converter.Convert(await _client.GetAssignmentsForEntityCode(entityCode));  
    }
}

