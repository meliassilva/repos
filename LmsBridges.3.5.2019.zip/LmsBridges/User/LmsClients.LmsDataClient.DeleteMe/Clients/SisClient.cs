﻿using Byui.LmsClients.LmsDataClient.Tools;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;
using MoreLinq.Extensions;

namespace Byui.LmsClients.LmsDataClient.Clients
{
    internal class SisClient
    {
        private readonly ApiClient _client;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="client"></param>
        public SisClient(ApiClient client)
        {
            _client = client;
        }

        /// <summary>
        /// Get sis users
        /// </summary>
        /// <returns></returns>
        public async Task<Response<List<User>>> GetSisUsers() => Converter.Convert(await _client.GetSisUsers());

        /// <summary>
        /// Get sis users by Semester Code
        /// </summary>
        /// <returns></returns>
        public async Task<Response<List<User>>> GetSisUsersFromSemesterCode(string semesterCode,bool cacheBust = true) => Converter.Convert(await _client.GetSisUsersFromSemesterCode(semesterCode,cacheBust));

        /// <summary>
        /// Get sis user from inumber
        /// </summary>
        /// <param name="iNumber"></param>
        /// <returns></returns>
        public async Task<Response<List<User>>> GetSisUserFromINumber(string iNumber) => Converter.Convert(await _client.GetSisUserFromINumber(iNumber));

        /// <summary>
        /// Get sis entities
        /// </summary>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Entity>>> GetSisEntities(string semesterCode, bool cacheBust = false) => Converter.Convert(await _client.GetSisEntities(semesterCode,cacheBust));

        /// <summary>
        /// Get sis sections
        /// </summary>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        public async Task<Response<List<SectionDetails>>> GetSisSections(string semesterCode,bool cacheBust = false)
        {
            Dictionary<string, Response<List<SectionDetails>>> sisSectionsResponse = await _client.GetSisSections(semesterCode,cacheBust);

            var mergedResponseDict = new Dictionary<string, Response<List<SectionDetails>>>();

            try
            {
                var cxSections = sisSectionsResponse[CommonObjectConstants.Cx.ToLower()].Data;
                var osmSections = sisSectionsResponse[CommonObjectConstants.Osm.ToLower()].Data;
                var cxErrors = sisSectionsResponse[CommonObjectConstants.Cx.ToLower()].Errors;
                var osmErrors = sisSectionsResponse[CommonObjectConstants.Osm.ToLower()].Errors;

                var cxSectionsDict = cxSections.DistinctBy(x => x.EntityCode).ToDictionary(x => x.EntityCode, x => x);
                var osmSectionsDict = osmSections.DistinctBy(x => x.EntityCode).ToDictionary(x => x.EntityCode, x => x);

                var commonSections = cxSections.Where(cxSection => osmSectionsDict.ContainsKey(cxSection.EntityCode)).ToList();
                var cxOnlySections = cxSections.Where(cxSection => !osmSectionsDict.ContainsKey(cxSection.EntityCode)).ToList();
                var osmOnlySections = osmSections.Where(osmSection =>!cxSectionsDict.ContainsKey(osmSection.EntityCode)).ToList();

                var mergedSections = commonSections.Select(cxSection =>
                GetMergedSection(cxSection, osmSections.FirstOrDefault(osmSection => cxSection.EntityCode == osmSection.EntityCode))).ToList();

                mergedResponseDict = new Dictionary<string, Response<List<SectionDetails>>>
                {
                    [CommonObjectConstants.Cx.ToLower()] = new Response<List<SectionDetails>> { Data = cxOnlySections },
                    [CommonObjectConstants.Cx.ToLower()] = { Errors = cxErrors },
                    [CommonObjectConstants.Osm.ToLower()] = new Response<List<SectionDetails>> { Data = osmOnlySections },
                    [CommonObjectConstants.Osm.ToLower()] = { Errors = osmErrors },
                    [$"{CommonObjectConstants.Cx.ToLower()},{CommonObjectConstants.Osm.ToLower()}"] = new Response<List<SectionDetails>> { Data = mergedSections }
                };
            }
            catch (Exception e)
            {
                mergedResponseDict[$"{CommonObjectConstants.Cx},{CommonObjectConstants.Osm}"] = new Response<List<SectionDetails>>();
                mergedResponseDict[$"{CommonObjectConstants.Cx},{CommonObjectConstants.Osm}"].Errors = new List<string> { e.Message };
            }

            return Converter.Convert(mergedResponseDict);
        }

        private SectionDetails GetMergedSection(SectionDetails cxSection, SectionDetails osmSection)
        {
            var mergedSection = cxSection;
            mergedSection.DevelopmentPhase = osmSection.DevelopmentPhase;
            mergedSection.CourseVariants = osmSection.CourseVariants;
            mergedSection.CourseVersion = osmSection.CourseVersion;
            mergedSection.SectionType = osmSection.SectionType;

            return mergedSection;
        }

        /// <summary>
        /// Get sis enrollments for section
        /// </summary>
        /// <param name="sectionCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> GetSisEnrollmentsForSection(string sectionCode) => Converter.Convert(await _client.GetSisEnrollmentsForSection(sectionCode));

        /// <summary>
        /// Get sis enrollments from inumber
        /// </summary>
        /// <param name="iNumber"></param>
        /// <param name="roleNames"></param>
        /// <param name="sessionCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> GetSisEnrollmentsFromINumber(string iNumber, List<string> roleNames, string sessionCode) => Converter.Convert(await _client.GetSisEnrollmentsFromINumber(iNumber, roleNames, sessionCode));

        /// <summary>
        /// Create or update sis enrollments
        /// </summary>
        /// <param name="enrollments"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> CreateOrUpdateSisEnrollments(List<Enrollment> enrollments) => Converter.Convert(await _client.CreateOrUpdateSisEnrollment(enrollments));

        /// <summary>
        /// Get final grades
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Response<List<SystemGrade>>> GetFinalGrades(string entityCode) => Converter.Convert(await _client.GetFinalGrade(entityCode));

        /// <summary>
        /// Set final grades
        /// </summary>
        /// <param name="finalGrades"></param>
        /// <param name="submitterINumber"></param>
        /// <returns></returns>
        public async Task<Response<List<SystemGrade>>> SetFinalGrades(List<SystemGrade> finalGrades, string submitterINumber) => Converter.Convert(await _client.SetFinalGrades(finalGrades, submitterINumber));

        /// <summary>
        /// Get valid grades for section
        /// </summary>
        /// <param name="sectionCode"></param>
        /// <returns></returns>
        public async Task<Response<List<string>>> GetValidGradesForSection(string sectionCode) => Converter.Convert(await _client.GetValidGradesForSection(sectionCode));

        /// <summary>
        /// Get semester
        /// </summary>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        public async Task<Response<Semester>> GetSemester(string semesterCode)
        {
            var response = await _client.GetSemester(semesterCode);
            var key = response.Keys.FirstOrDefault();

            return response[key ?? throw new InvalidOperationException()];
        }

        /// <summary>
        /// Get semester for section
        /// </summary>
        /// <param name="sectionCode"></param>
        /// <returns></returns>
        public async Task<Response<Semester>> GetSemesterForSection(string sectionCode)
        {
            var response = await _client.GetSemesterForSection(sectionCode);
            var key = response.Keys.FirstOrDefault();

            return response[key ?? throw new InvalidOperationException()];
        }

        /// <summary>
        /// Get current semester
        /// </summary>
        /// <returns></returns>
        public async Task<Response<Semester>> GetCurrentSemester()
        {
            var response = await _client.GetCurrentSemester();
            var key = response.Keys.FirstOrDefault();

            return response[key ?? throw new InvalidOperationException()];
        }

        /// <summary>
        /// Get semester by date
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public async Task<Response<Semester>> GetSemesterByDate(DateTime date)
        {
            var response = await _client.GetSemesterByDate(date);
            var key = response.Keys.FirstOrDefault();

            return response[key ?? throw new InvalidOperationException()];
        }

        /// <summary>
        /// Get previous semester
        /// </summary>
        /// <returns></returns>
        public async Task<Response<Semester>> GetPreviousSemester()
        {
            var response = await _client.GetPreviousSemester();
            var key = response.Keys.FirstOrDefault();

            return response[key ?? throw new InvalidOperationException()];
        }

        /// <summary>
        /// Get next semester
        /// </summary>
        /// <returns></returns>
        public async Task<Response<Semester>> GetNextSemester()
        {
            var response = await _client.GetNextSemester();
            var key = response.Keys.FirstOrDefault();

            return response[key ?? throw new InvalidOperationException()];
        }

        /// <summary>
        /// Get final grade Submission semester
        /// </summary>
        /// <returns></returns>
        public async Task<Response<Semester>> GetFinalGradeSubmissionSemester()
        {
            var response = await _client.GetFinalGradeSubmissionSemester();
            var key = response.Keys.FirstOrDefault();

            return response[key ?? throw new InvalidOperationException()];
        }
    }
}
