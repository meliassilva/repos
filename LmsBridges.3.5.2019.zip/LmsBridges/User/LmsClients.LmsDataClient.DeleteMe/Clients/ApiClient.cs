﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;
using Flurl;
using Newtonsoft.Json;

namespace Byui.LmsClients.LmsDataClient.Clients
{
    internal class ApiClient
    {
        private readonly BaseClient _client;
        private readonly string _connectionString;

        public ApiClient(BaseClient client)
        {
            _client = client;
            _connectionString = _client.ConnectionString;
        }

        /// <summary>
        /// Get enrollment from entity
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> SyncInstructorEnrollments(string entityCode)
        {
            var jsonContent = await SendGet($"{_connectionString}/sis/entities/{entityCode}/enrollments/instructor/sync");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(jsonContent);
        }

        /// <summary>
        /// Get enrollment from entity
        /// </summary>
        /// <param name="entityCode"></param>
        /// <param name="cacheBust"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> GetEnrollmentsFromEntity(string entityCode,bool cacheBust)
        {
            var jsonContent = await SendGet($"{_connectionString}/lms/enrollments/{entityCode}?cacheBust={cacheBust}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>> (jsonContent);
        }

        /// <summary>
        /// Get enrollment from inumber
        /// </summary>
        /// <param name="iNumber"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> GetEnrollmentsFromINumber(string iNumber)
        {
            var responseJson = await SendGet($"{_connectionString}/lms/users/{iNumber}/enrollments");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(responseJson);
        }

        /// <summary>
        /// Get enrollment from entity from inumber
        /// </summary>
        /// <param name="entityCode"></param>
        /// <param name="iNumber"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> GetEnrollmentFromEntityFromINumber(string entityCode, string iNumber)
        {
            var responseJson = await SendGet($"{_connectionString}/lms/entities/{entityCode}/users/{iNumber}/enrollment");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(responseJson);
        }


        /// <summary>
        /// Get entities
        /// </summary>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Entity>>>> GetEntities(string semesterCode,bool cacheBust=false)
        {
            var responseJson = await SendGet($"{_connectionString}/lms/entities/{semesterCode}/entities?cacheBust={cacheBust}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Entity>>>>(responseJson);
        }

        /// <summary>
        /// Create or update enrollments
        /// </summary>
        /// <param name="enrollmentsRequest"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<ChangeReport<Enrollment>>>> CreateOrUpdateEnrollments(List<EnrollmentRequest> enrollmentsRequest)
        {
            var responseJson = await SendPost($"{_connectionString}/lms/enrollments", enrollmentsRequest);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<ChangeReport<Enrollment>>>>(responseJson);
        }

        /// <summary>
        /// Delete enrollments
        /// </summary>
        /// <param name="deleteRequests"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> DeleteEnrollments(List<EnrollmentRequest> deleteRequests)
        {
            var responseJson = await SendDelete($"{_connectionString}/lms/enrollments", deleteRequests);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(responseJson);

            //List<string> _iNumbers = deleteRequests.Select(x => x.INumber).ToList();
            //List<string> _entityCodes = deleteRequests.Select(x => x.SectionCode).ToList();
            //List<string> _roles = deleteRequests.Select(x => x.RoleName).ToList();
            //var url = new Url(_connectionString).AppendPathSegment("/lms/enrollments/delete");
            //url.SetQueryParams(new
            //{
            //    inumbers = _iNumbers,
            //    entity_codes = _entityCodes,
            //    roles = _roles
            //});

            //HttpResponseMessage response = await _client.SendCall(url, HttpMethod.Delete);
            //string responseJson = await response.Content.ReadAsStringAsync();
            //var result = JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(responseJson);

            //return result;
        }

        public async Task<Dictionary<string, Response<ChangeReport<ContentMigration>>>> CopyCourses(List<CopyRequest> copyRequests)
        {
            var responseJson = await SendPost($"{_connectionString}/lms/copy", copyRequests);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<ChangeReport<ContentMigration>>>>(responseJson);
        }

        public async Task<Dictionary<string, Response<Progress>>> GetCopyStatus(string copyProgressId)
        {
            var responseJson = await SendGet($"{_connectionString}/lms/copy/status/" + copyProgressId);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<Progress>>>(responseJson);
        }

        /// <summary>
        /// Get entity by code
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<Entity>>> GetEntityByCode(string entityCode)
        {
            var semesterCode = GetSemesterCodeFromEntityCode(entityCode);
            var responseJson = await SendGet($"{_connectionString}/lms/entities/{entityCode}".SetQueryParam("semesterCode", semesterCode));
            return JsonConvert.DeserializeObject<Dictionary<string, Response<Entity>>>(responseJson);
        }

        /// <summary>
        /// Get entities by code
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Entity>>>> GetEntitiesByCode(string entityCode)
        {
            var semesterCode = GetSemesterCodeFromEntityCode(entityCode);
            var responseJson = await SendGet($"{_connectionString}/lms/entity".SetQueryParam("semesterCode", semesterCode));
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Entity>>>>(responseJson);
        }

        /// <summary>
        /// Get semester code from entity code
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        private string GetSemesterCodeFromEntityCode(string entityCode)
        {
            var codeParts = entityCode.Split('.');
            if (codeParts.Length > 4)
            {
                return $"{codeParts[1]}.{codeParts[2]}";
            }

            return entityCode;
        }

        /// <summary>
        /// Create or update entities
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<ChangeReport<Entity>>>> CreateOrUpdateEntities(List<Entity> entities)
        {
            var semesterCode = "todoImplementFunctionToGetSemesterCode";
            var responseJson = await SendPost($"{_connectionString}/lms/entities".SetQueryParam("semester", semesterCode), entities);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<ChangeReport<Entity>>>>(responseJson);
        }

        /// <summary>
        /// Delete entities
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<string>>>> DeleteEntities(List<string> entities)
        {
            //var semesterCode = "todoWriteFunctionToGetSemesterCodesAndLoop";
            
            //TODO: Probably this one needs to be fixed
            var responseJson = await SendDelete($"{_connectionString}/lms/entities", entities);

            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<string>>>>(responseJson);
        }

        /// <summary>
        /// Gets Users in a given class
        /// </summary>
        /// <param name="entityCode">The entity code for the class</param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<User>>>> GetUsersInClassByEntity(string entityCode)
        {
            var responseJson = await SendGet($"{_connectionString}/lms/users/{entityCode}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<User>>>>(responseJson);
        }

        /// <summary>
        /// Get users
        /// </summary>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<User>>>> GetUsers()
        {
            var responseJson = await SendGet($"{_connectionString}/lms/users");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<User>>>>(responseJson);
        }

        /// <summary>
        /// Get user from inumber.
        /// </summary>
        /// <param name="iNumber"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<User>>> GetUserFromINumber(string iNumber)
        {
            var responseJson = await SendGet($"{_connectionString}/lms/user/{iNumber}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<User>>>(responseJson);
        }

        /// <summary>
        /// Create or update users
        /// </summary>
        /// <param name="users"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<ChangeReport<User>>>> CreateOrUpdateLmsUsers(List<User> users,string systemName)
        {
            var responseJson = await SendPost($"{_connectionString}/lms/users?system={systemName}", users);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<ChangeReport<User>>>>(responseJson);
        }

        /// <summary>
        /// Get cache users
        /// </summary>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<User>>>> GetCacheUsers()
        {
            var responseJson = await SendGet($"{_connectionString}/cache/users");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<User>>>>(responseJson);
        }

        /// <summary>
        /// Get cache users
        /// </summary>
        /// <param name="iNumbers"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<User>>>> GetCacheUsers(List<string> iNumbers)
        {
            var responseJson = await SendPost($"{_connectionString}/cache/users/GetMultipleByINumber", iNumbers);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<User>>>>(responseJson);
        }

        /// <summary>
        /// Create or update cache users
        /// </summary>
        /// <param name="users"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<ChangeReport<User>>>> CreateOrUpdateCacheUsers(List<User> users)
        {
            var responseJson = await SendPost($"{_connectionString}/cache/users", users);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<ChangeReport<User>>>>(responseJson);
        }

        /// <summary>
        /// Get cache entity
        /// </summary>
        /// <param name="system"></param>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Entity>>>> GetCacheEntity(string system, string entityCode)
        {
            var responseJson = await SendGet($"{_connectionString}/cache/systems/{system}/entityCode/{entityCode}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Entity>>>>(responseJson);
        }

        /// <summary>
        /// create or update cache entities
        /// </summary>
        /// <param name="entities"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<ChangeReport<Entity>>>> CreateOrUpdateCacheEntities(List<Entity> entities)
        {
            var responseJson = await SendPost($"{_connectionString}/cache/entities", entities);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<ChangeReport<Entity>>>>(responseJson);
        }

        /// <summary>
        /// Get enrollments from cache entity
        /// </summary>
        /// <param name="system"></param>
        /// <param name="entityCode"></param>
        /// <param name="roleNames"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> GetEnrollmentsFromCacheEntity(string system, string entityCode, List<string> roleNames)
        {
            var responseJson =
                await SendGet($"{_connectionString}/cache/systems/{system}/entities/{entityCode}/enrollments".SetQueryParam("roleNames", roleNames));
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(responseJson);
        }

        /// <summary>
        /// Get enrollments from cache inumber
        /// </summary>
        /// <param name="system"></param>
        /// <param name="iNumber"></param>
        /// <param name="roleNames"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> GetEnrollmentsFromCacheINumber(string system, string iNumber, List<string> roleNames)
        {
            var responseJson =
                await SendGet($"{_connectionString}/cache/systems/{system}/users/{iNumber}/enrollments"
                    .SetQueryParam("role_names", roleNames));
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(responseJson);
        }

        /// <summary>
        /// Get users form cache entitye
        /// </summary>
        /// <param name="system"></param>
        /// <param name="entityCode"></param>
        /// <param name="roleNames"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<User>>>> GetUsersFromCacheEntity(string system,
            string entityCode, List<string> roleNames)
        {
            var responseJson =
                await SendGet($"{_connectionString}/cache/systems/{system}/entities/{entityCode}/people"
                    .SetQueryParams(new {role_names = roleNames}));
        return JsonConvert.DeserializeObject<Dictionary<string, Response<List<User>>>>(responseJson);
        }

        /// <summary>
        /// Get sis users
        /// </summary>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<User>>>> GetSisUsers()
        {
            var responseJson = await SendGet($"{_connectionString}/sis/users");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<User>>>>(responseJson);
        }

        /// <summary>
        /// Get sis users by Semester Code
        /// </summary>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<User>>>> GetSisUsersFromSemesterCode(string semesterCode,bool cacheBust)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/{semesterCode}/users?cacheBust={cacheBust}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<User>>>>(responseJson);
        }

        /// <summary>
        /// Get sis user from inumber
        /// </summary>
        /// <param name="iNumber"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<User>>> GetSisUserFromINumber(string iNumber)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/users/{iNumber}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<User>>>(responseJson);
        }

        /// <summary>
        /// Get sis entities
        /// </summary>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Entity>>>> GetSisEntities(string semesterCode,bool cacheBust)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/entities?semesterCode={semesterCode}&cacheBust={cacheBust}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Entity>>>>(responseJson);
        }

        /// <summary>
        /// Get sis sections
        /// </summary>
        /// <param name="semesterCode"></param>
        /// <param name="cacheBust"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<SectionDetails>>>> GetSisSections(string semesterCode,bool cacheBust=false)
        {
                Dictionary<string, Response<List<SectionDetails>>> sections = new Dictionary<string, Response<List<SectionDetails>>>();
                try
                {
                    var responseJson = await SendGet($"{_connectionString}/sis/sections/{semesterCode}?cacheBust={cacheBust}");
                    sections = JsonConvert.DeserializeObject<Dictionary<string, Response<List<SectionDetails>>>>(responseJson);
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Error writing file {e.Message}");
                }

                return sections;
        }

        /// <summary>
        /// Get sis enrollments for section
        /// </summary>
        /// <param name="sectionCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> GetSisEnrollmentsForSection(string sectionCode)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/entities/{sectionCode}/enrollments");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(responseJson);
        }

        /// <summary>
        /// Get sis enrollments from inumber
        /// </summary>
        /// <param name="iNumber"></param>
        /// <param name="roleNames"></param>
        /// <param name="sessionCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> GetSisEnrollmentsFromINumber(string iNumber, List<string> roleNames, string sessionCode)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/users/{iNumber}/enrollments".SetQueryParam("roles", roleNames).SetQueryParam("sessionCode", sessionCode));
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(responseJson);
        }

        /// <summary>
        /// Create or update sis enrollment
        /// </summary>
        /// <param name="enrollments"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> CreateOrUpdateSisEnrollment(List<Enrollment> enrollments)
        {
            var responseJson = await SendPost($"{_connectionString}/enrollments", enrollments);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Enrollment>>>>(responseJson);
        }

        public async Task<Dictionary<string, Response<List<SystemGrade>>>> GetLmsFinalGrade(string entityCode)
        {
            var responseJson = await SendGet($"{_connectionString}/lms/entities/{entityCode}/finalGrades");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<SystemGrade>>>>(responseJson);
        }

        /// <summary>
        /// Get final grade
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<SystemGrade>>>> GetFinalGrade(string entityCode)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/entities/{entityCode}/finalGrades");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<SystemGrade>>>>(responseJson);
        }

        /// <summary>
        /// Set final grade
        /// </summary>
        /// <param name="finalGrades"></param>
        /// <param name="submitterINumber"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<SystemGrade>>>> SetFinalGrades(List<SystemGrade> finalGrades, string submitterINumber)
        {
            var responseJson = await SendPost($"{_connectionString}/sis/finalGrades?submitterINumber={submitterINumber}", finalGrades);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<SystemGrade>>>>(responseJson);
        }
    
        /// <summary>
        /// Get valid grade for section
        /// </summary>
        /// <param name="sectionCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<string>>>> GetValidGradesForSection(string sectionCode)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/entities/{sectionCode}/validGradeValues");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<string>>>>(responseJson);
        }

        /// <summary>
        /// Get semester
        /// </summary>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<Semester>>> GetSemester(string semesterCode)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/semesters/{semesterCode}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<Semester>>>(responseJson);
        }

        /// <summary>
        /// Get semesters for section
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<Semester>>> GetSemesterForSection(string entityCode)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/entities/{entityCode}/semester");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<Semester>>>(responseJson);
        }

        /// <summary>
        /// Get current semester
        /// </summary>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<Semester>>> GetCurrentSemester()
        {
            var responseJson = await SendGet($"{_connectionString}/sis/semesters/current");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<Semester>>>(responseJson);
        }
        
        /// <summary>
        /// Get semester by date
        /// </summary>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<Semester>>> GetSemesterByDate(DateTime date)
        {
            var responseJson = await SendGet($"{_connectionString}/sis/semesters/date/{date}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<Semester>>>(responseJson);
        }

        /// Get previous semester
        /// </summary>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<Semester>>> GetPreviousSemester()
        {
            var responseJson = await SendGet($"{_connectionString}/sis/semesters/previous");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<Semester>>>(responseJson);
        }

        /// <summary>
        /// Get next semester
        /// </summary>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<Semester>>> GetNextSemester()
        {
            var responseJson = await SendGet($"{_connectionString}/sis/semesters/next");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<Semester>>>(responseJson);
        }

        /// <summary>
        /// Get final grade submit semester
        /// </summary>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<Semester>>> GetFinalGradeSubmissionSemester()
        {
            var responseJson = await SendGet($"{_connectionString}/sis/semesters/finalgradesubmit");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<Semester>>>(responseJson);
        }

        /// <summary>
        /// Get assignemnts for entity code
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Assignments>>>> GetAssignmentsForEntityCode(string entityCode)
        {
            var responseJson = await SendGet($"{_connectionString}/lms/assignments/{entityCode}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<Assignments>>>>(responseJson);
        }

        /// <summary>
        /// Get email templates by system
        /// </summary>
        /// <param name="systemName"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<EmailTemplate>>>> GetEmailTemplatesBySystem(string systemName)
        {
            var responseJson = await SendGet($"{_connectionString}/email/templates/system/{systemName}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<EmailTemplate>>>>(responseJson);
        }

        /// <summary>
        /// Get email template
        /// </summary>
        /// <param name="systemName"></param>
        /// <param name="templateName"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<EmailTemplate>>>> GetEmailTemplate(string systemName, string templateName)
        {
            var responseJson = await SendGet($"{_connectionString}/email/templates/system/{systemName}/name/{templateName}");
            return JsonConvert.DeserializeObject<Dictionary<string, Response<List<EmailTemplate>>>>(responseJson);
        }

        /// <summary>
        /// Create email template
        /// </summary>
        /// <param name="template"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<EmailTemplate>>> CreateEmailTemplate(EmailTemplate template)
        {
            var responseJson = await SendPost($"{_connectionString}/email/templates", template);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<EmailTemplate>>>(responseJson);
        }

        /// <summary>
        /// Update email template
        /// </summary>
        /// <param name="systemName"></param>
        /// <param name="templateName"></param>
        /// <param name="template"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<EmailTemplate>>> UpdateEmailTemplate(string systemName, string templateName, EmailTemplate template)
        {
            var responseJson = await SendPost($"{_connectionString}/email/templates/system/{systemName}/name/{templateName}", template);
            return JsonConvert.DeserializeObject<Dictionary<string, Response<EmailTemplate>>>(responseJson);
        }

        /// <summary>
        /// Send get request
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private async Task<string> SendGet(Url url)
        {
            var response = await _client.SendCall(url, HttpMethod.Get);
            return await response.Content.ReadAsStringAsync();
        }

        /// <summary>
        /// Send post request
        /// </summary>
        /// <param name="url"></param>
        /// <param name="body"></param>
        /// <returns></returns>
        private async Task<string> SendPost(Url url, object body)
        {
            var response = await _client.SendCall(url, HttpMethod.Post, body);
            return await response.Content.ReadAsStringAsync();
        }
        
        /// <summary>
        /// Send delete request
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private async Task<string> SendDelete(Url url, object body)
        {
            var response = await _client.SendCall(url, HttpMethod.Delete, body);
            return await response.Content.ReadAsStringAsync();
        }
    }
}
