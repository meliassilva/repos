﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Flurl;
using Flurl.Http;
using Newtonsoft.Json.Linq;

namespace Byui.LmsClients.LmsDataClient.Clients
{
    internal class BaseClient
    {
        private readonly string _key;
        private readonly string _secret;
        private string _oAuthToken;
        public readonly string ConnectionString;

        /// <summary>
        /// Base client constructor
        /// </summary>
        /// <param name="key"></param>
        /// <param name="secret"></param>
        /// <param name="url"></param>
        public BaseClient(string key, string secret, string url = null)
        {
            _key = key;
            _secret = secret;
            ConnectionString = url ?? "https://apitemp.byui.edu/LmsData/v3";
            RenewOAuthToken();
        }

        public BaseClient(int port)
        {
            ConnectionString = $"http://localhost:{port}";
        }

        /// <summary>
        /// Renew oAuth token
        /// </summary>
        private void RenewOAuthToken()
        {
            try
            {
                var url = new Url("https://apitemp.byui.edu/token");
                var bytes = Encoding.UTF8.GetBytes($"{_key}:{_secret}");
                var convertedString = Convert.ToBase64String(bytes);

                url.SetQueryParam("grant_type", "client_credentials");

                var response = url.WithHeader("Authorization", $"Basic {convertedString}").SendAsync(HttpMethod.Post).Result;
                var responseObj = JObject.Parse(response.Content.ReadAsStringAsync().Result);

                _oAuthToken = responseObj["access_token"].ToString();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

        /// <summary>
        /// Send call
        /// </summary>
        /// <param name="url"></param>
        /// <param name="method"></param>
        /// <param name="requestObject"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> SendCall<T>(Url url, HttpMethod method, T requestObject)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = await url.WithTimeout(30000).WithOAuthBearerToken(_oAuthToken).
                    SendJsonAsync(method, requestObject);
            }
            catch (Exception)
            {
                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    RenewOAuthToken();
                    response = await SendCall(url, method, requestObject);
                }
                else
                {
                    throw;
                }
            }
            return response;
        }/// <summary>
        /// Send call
        /// </summary>
        /// <param name="url"></param>
        /// <param name="method"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> SendCall(Url url, HttpMethod method)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = await url.WithTimeout(30000).WithOAuthBearerToken(_oAuthToken).
                    SendJsonAsync(method,null);
            }
            catch (Exception)
            {
                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    RenewOAuthToken();
                    response = await SendCall(url, method);
                }
                else
                {
                    throw;
                }
            }
            return response;
        }
    }
}
