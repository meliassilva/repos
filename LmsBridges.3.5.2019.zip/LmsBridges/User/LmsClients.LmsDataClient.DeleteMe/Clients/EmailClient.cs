﻿using Byui.LmsClients.LmsDataClient.Tools;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Byui.LmsClients.LmsDataClient.Clients
{
    internal class EmailClient
    {
        private readonly ApiClient _client;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="apiClient"></param>
        public EmailClient(ApiClient apiClient)
        {
            _client = apiClient;
        }
        
        /// <summary>
        /// Get email templates by system
        /// </summary>
        /// <param name="systemName"></param>
        /// <returns></returns>
        public async Task<Response<List<EmailTemplate>>> GetEmailTemplatesBySystem(string systemName) => Converter.Convert(await _client.GetEmailTemplatesBySystem(systemName));
        
        public async Task<Response<List<EmailTemplate>>> GetEmailTemplates(string systemName, string templateName) => Converter.Convert(await _client.GetEmailTemplate(systemName, templateName));
        
        public async Task<Response<List<EmailTemplate>>> CreateEmailTemplate(EmailTemplate template) => Converter.Convert(await _client.CreateEmailTemplate(template));
        
        public async Task<Response<List<EmailTemplate>>> UpdateEmailTemplate(string systemName, string templateName, EmailTemplate template) => Converter.Convert(await _client.UpdateEmailTemplate(systemName, templateName, template));
    }
}

