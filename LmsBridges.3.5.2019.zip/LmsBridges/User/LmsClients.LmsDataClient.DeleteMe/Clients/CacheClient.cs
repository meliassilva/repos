﻿using Byui.LmsClients.LmsDataClient.Tools;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Byui.LmsClients.LmsDataClient.Clients
{
    internal class CacheClient
    {
        private readonly ApiClient _client;

        public CacheClient(ApiClient client)
        {
            _client = client;
        }

        /// <summary>
        /// Get cache users
        /// </summary>
        /// <returns></returns>
        public async Task<Response<List<User>>> GetCacheUsers() => Converter.Convert(await _client.GetCacheUsers());

        /// <summary>
        /// Get cache users
        /// </summary>
        /// <param name="iNumbers"></param>
        /// <returns></returns>
        public async Task<Response<List<User>>> GetCacheUsers(List<string> iNumbers) => Converter.Convert(await _client.GetCacheUsers(iNumbers));

        /// <summary>
        /// Create or update cache users
        /// </summary>
        /// <param name="users"></param>
        /// <returns></returns>
        public async Task<Response<ChangeReport<User>>> CreateOrUpdateCacheUsers(List<User> users) => Converter.Convert(await _client.CreateOrUpdateCacheUsers(users));

        /// <summary>
        /// Get cache entity
        /// </summary>
        /// <param name="system"></param>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Entity>>> GetCacheEntity(string system, string entityCode) => Converter.Convert(await _client.GetCacheEntity(system, entityCode));

        /// <summary>
        /// Create or update cache entities
        /// </summary>
        /// <param name="entities"></param>
        /// <returns></returns>
        public async Task<Response<ChangeReport<Entity>>> CreateOrUpdateCacheEntities(List<Entity> entities) => Converter.Convert(await _client.CreateOrUpdateCacheEntities(entities));

        /// <summary>
        /// Get enrollments from cache entity
        /// </summary>
        /// <param name="system"></param>
        /// <param name="entityCode"></param>
        /// <param name="roleNames"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> GetEnrollmentsFromCacheEntity(string system, string entityCode, List<string> roleNames) => Converter.Convert(await _client.GetEnrollmentsFromCacheEntity(system, entityCode, roleNames));

        /// <summary>
        /// Get enrollments from cache inumber
        /// </summary>
        /// <param name="system"></param>
        /// <param name="iNumber"></param>
        /// <param name="roleNames"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> GetEnrollmentsFromCacheINumber(string system, string iNumber, List<string> roleNames) => Converter.Convert(await _client.GetEnrollmentsFromCacheINumber(system, iNumber, roleNames));

        /// <summary>
        /// Get users from cache entity
        /// </summary>
        /// <param name="system"></param>
        /// <param name="entityCode"></param>
        /// <param name="roleNames"></param>
        /// <returns></returns>
        public async Task<Response<List<User>>> GetUsersFromCacheEntity(string system, string entityCode, List<string> roleNames) => Converter.Convert(await _client.GetUsersFromCacheEntity(system, entityCode, roleNames));
    }
}
