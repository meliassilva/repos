﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Byui.LmsClients.LmsDataClient.Tools;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LmsClients.LmsDataClient.Clients
{
    internal class EnrollmentClient
    {
        private readonly ApiClient _client;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="apiClient"></param>
        public EnrollmentClient(ApiClient apiClient)
        {
            _client = apiClient;
        }

        /// <summary>
        /// Get enrollments from entity
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> SyncInstructorEnrollments(string entityCode) => Converter.Convert(await _client.SyncInstructorEnrollments(entityCode));


        /// <summary>
        /// Get enrollments from entity
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> GetLmsEnrollmentsFromEntity(string entityCode,bool cacheBust=true) => Converter.Convert(await _client.GetEnrollmentsFromEntity(entityCode,cacheBust));

        /// <summary>
        /// Get enrollments from entity without conversion
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, Response<List<Enrollment>>>> GetEnrollmentsFromEntityDetailed(string entityCode, bool cacheBust = true) => await _client.GetEnrollmentsFromEntity(entityCode, cacheBust);

        /// <summary>
        /// Get enrollments from inumber
        /// </summary>
        /// <param name="iNumber"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> GetLmsEnrollmentsFromINumber(string iNumber) => Converter.Convert(await _client.GetEnrollmentsFromINumber(iNumber));

        /// <summary>
        /// Get enrollments from entity from inumber
        /// </summary>
        /// <param name="entityCode"></param>
        /// <param name="iNumber"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> GetLmsEnrollmentFromEntityFromINumber(string entityCode, string iNumber) => Converter.Convert(await _client.GetEnrollmentFromEntityFromINumber(entityCode, iNumber));

        /// <summary>
        /// Create or update enrollments
        /// </summary>
        /// <param name="enrollments"></param>
        /// <returns></returns>
        public async Task<Response<ChangeReport<Enrollment>>> CreateOrUpdateLmsEnrollments(List<EnrollmentRequest> enrollments) => Converter.Convert(await _client.CreateOrUpdateEnrollments(enrollments));

        /// <summary>
        /// Delete enrollments
        /// </summary>
        /// <param name="deleteRequests"></param>
        /// <returns></returns>
        public async Task<Response<List<Enrollment>>> DeleteLmsEnrollments(List<EnrollmentRequest> deleteRequests) => Converter.Convert(await _client.DeleteEnrollments(deleteRequests));
    }
}
