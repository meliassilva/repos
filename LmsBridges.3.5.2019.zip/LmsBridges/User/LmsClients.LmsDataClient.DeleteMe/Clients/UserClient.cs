﻿using Byui.LmsClients.LmsDataClient.Tools;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Byui.LmsClients.LmsDataClient.Clients
{
    internal class UserClient
    {
        private readonly ApiClient _client;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="client"></param>
        public UserClient(ApiClient client)
        {
            _client = client;
        }

        /// <summary>
        /// Get users
        /// </summary>
        /// <returns></returns>
        public async Task<Response<List<User>>> GetUsers() => Converter.Convert(await _client.GetUsers());

        /// <summary>
        /// Get final grades
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Response<List<SystemGrade>>> GetLmsFinalGrade(string entityCode) => Converter.Convert(await _client.GetLmsFinalGrade(entityCode));


        /// <summary>
        /// Create or update users
        /// </summary>
        /// <param name="users"></param>
        /// <returns></returns>
        public async Task<Response<ChangeReport<User>>> CreateOrUpdateUsers(List<User> users,string system) => Converter.Convert(await _client.CreateOrUpdateLmsUsers(users,system));

        /// <summary>
        /// Get user from inumber
        /// </summary>
        /// <param name="iNumber"></param>
        /// <returns></returns>
        public async Task<Response<List<User>>> GetUserFromINumber(string iNumber) => Converter.Convert(await _client.GetUserFromINumber(iNumber));

        /// <summary>
        /// Gets users in a given class by entity code
        /// </summary>
        /// <param name="entityCode">The Entity Code for a given class</param>
        /// <returns></returns>
        public async Task<Response<List<User>>> GetUsersInClassByEntity(string entityCode) => Converter.Convert(await _client.GetUsersInClassByEntity(entityCode));
    }
}
