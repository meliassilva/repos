﻿using System;
using Byui.LmsClients.LmsDataClient.Tools;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;
using Newtonsoft.Json;

namespace Byui.LmsClients.LmsDataClient.Clients
{
    internal class EntityClient
    {
        private readonly ApiClient _client;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="apiClient"></param>
        public EntityClient(ApiClient apiClient)
        {
            _client = apiClient;
        }

        /// <summary>
        /// Get entities
        /// </summary>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Entity>>> GetLmsEntities(string semesterCode,bool cacheBust=false) => Converter.Convert(await _client.GetEntities(semesterCode,cacheBust));

        /// <summary>
        /// Get entities
        /// </summary>
        /// <param name="semesterCode"></param>
        /// <returns></returns>
        internal async Task<Response<List<SectionDetails>>> GetLmsSectionsForSemester(string semesterCode,bool cacheBust = false)
        {
            var response = new Response<List<SectionDetails>>();
           
                try
                {
                    var entityResponse = await _client.GetEntities(semesterCode);
                    var entities = Converter.Convert(entityResponse);
                    var sections = entities.Data.Where(entity => entity.EntityType?.ToLower() == "section" || entity.Name.ToLower().Contains("section")).ToList();
                    response.Data = Converter.ConvertEntityListToSectionDetailsList(sections);
                }
                catch (Exception e)
                {
                    response.Errors.Add($"{e.Message}");
                }

            return response;
        }

        /// <summary>
        /// Get entity by code
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Entity>>> GetLmsEntityByCode(string entityCode) => Converter.Convert(await _client.GetEntityByCode(entityCode));

        /// <summary>
        /// Post Courses to be copied and get a ChangeReport for the ContentMigrations
        /// </summary>
        /// <param name="copyRequests"></param>
        /// <returns>A ChangeReport of ContentMigration(s)</returns>
        public async Task<Response<ChangeReport<ContentMigration>>> CopyCourses(List<CopyRequest> copyRequests) => 
            Converter.Convert(await _client.CopyCourses(copyRequests));

        /// <summary>
        /// Get the Copy status of a given progressId
        /// </summary>
        /// <param name="copyProgressId">The Progress Id returned in the ContentMigration object</param>
        /// <returns>A List of Progresses</returns>
        public async Task<Response<List<Progress>>> GetCopyStatus(string copyProgressId) => 
            Converter.Convert(await _client.GetCopyStatus(copyProgressId));

        /// <summary>
        /// Get lms entities by code
        /// </summary>
        /// <param name="entityCode"></param>
        /// <returns></returns>
        public async Task<Response<List<Entity>>> GetLmsEntitiesByCode(string entityCode) =>
            Converter.Convert(await _client.GetEntitiesByCode(entityCode));

        /// <summary>
        /// Create or update entities
        /// </summary>
        /// <param name="entities"></param>
        /// <returns></returns>
        public async Task<Response<ChangeReport<Entity>>> CreateOrUpdateLmsEntities(List<Entity> entities) => Converter.Convert(await _client.CreateOrUpdateEntities(entities));

        /// <summary>
        /// Delete entities
        /// </summary>
        /// <param name="entities"></param>
        /// <returns></returns>
        public async Task<Response<List<string>>> DeleteLmsEntities(List<string> entities) => Converter.Convert(await _client.DeleteEntities(entities));
        
    }
}
