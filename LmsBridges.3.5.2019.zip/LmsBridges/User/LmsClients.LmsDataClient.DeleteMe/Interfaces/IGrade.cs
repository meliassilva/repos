﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LmsClients.LmsDataClient.Interfaces
{
    public interface IGrade
    {
        Task<Response<List<SystemGrade>>> GetFinalGrades(string entityCode);
        Task<Response<List<SystemGrade>>> SetFinalGrades(List<SystemGrade> finalGrades, string submitterINumber);
        Task<Response<List<string>>> GetValidGradesForSection(string sectionCode);
    }
}