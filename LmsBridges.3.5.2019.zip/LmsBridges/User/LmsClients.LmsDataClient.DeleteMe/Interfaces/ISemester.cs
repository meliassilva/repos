﻿using System;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LmsClients.LmsDataClient.Interfaces
{
    public interface ISemester
    {
        Task<Response<Semester>> GetSemesterForSection(string sectionCode);
        Task<Response<Semester>> GetCurrentSemester();
        Task<Response<Semester>> GetSemesterByDate(DateTime date);
        Task<Response<Semester>> GetPreviousSemester();
        Task<Response<Semester>> GetNextSemester();
        Task<Response<Semester>> GetFinalGradeSubmissionSemester();
    }
}