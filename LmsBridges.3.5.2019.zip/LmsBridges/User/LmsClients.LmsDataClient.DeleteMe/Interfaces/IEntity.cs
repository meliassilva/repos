﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Filters;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LmsClients.LmsDataClient.Interfaces
{
    public interface IEntity
    {
        Task<Response<List<Entity>>> GetLmsEntities(string semesterCode,bool cacheBust);
        Task<Response<List<Entity>>> GetLmsEntityFromCode(string entityCode);
        Task<Response<ChangeReport<Entity>>> CreateOrUpdateLmsEntities(List<Entity> entities);
        Task<Response<List<string>>> DeleteLmsEntities(List<string> entityCodes);
        Task<Response<List<Entity>>> GetCacheEntity(string system, string entityCode);
        Task<Response<ChangeReport<Entity>>> CreateOrUpdateCacheEntities(List<Entity> entities);
        Task<Response<List<Entity>>> GetSisEntities(string semesterCode, bool cacheBust = false);
        Task<Response<List<SectionDetails>>> GetSisSections(string semesterCode);
        Task<Response<List<SectionDetails>>> GetSectionDetails(SectionFilter sectionFilter);
        Task<Response<List<Progress>>> GetCopyStatus(string copyProgressId);
        Task<Response<ChangeReport<ContentMigration>>> CopyCourses(List<CopyRequest> copyRequests);
    }
}