﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LmsClients.LmsDataClient.Interfaces
{
    public interface IUsers
    {
        Task<Response<List<User>>> GetUsersFromCacheEntity(string system, string entityCode, List<string> roleNames);
        Task<Response<List<User>>> GetSisUsers();
        Task<Response<List<User>>> GetSisUserFromINumber(string iNumber);
        Task<Response<List<User>>> GetUsers();
        Task<Response<ChangeReport<User>>> CreateOrUpdateUsers(List<User> users,string system);
        Task<Response<List<User>>> GetUserFromINumber(string iNumber);
        Task<Response<List<User>>> GetUsersInClassByEntity(string entityCode);
        Task<Response<List<User>>> GetCacheUsers();
        Task<Response<List<User>>> GetCacheUsers(List<string> iNumbers);
        Task<Response<ChangeReport<User>>> CreateOrUpdateCacheUsers(List<User> users);
        Task<Response<List<SystemGrade>>> GetLmsFinalGrade(string entity);
    }
}