﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LmsClients.LmsDataClient.Interfaces
{
    public interface IEnrollment
    {
        Task<Response<List<Enrollment>>> GetLmsEnrollmentsFromEntity(string entityCode,bool cacheBust);
        Task<Response<List<Enrollment>>> GetLmsEnrollmentsFromINumber(string iNumber);
        Task<Response<List<Enrollment>>> GetLmsEnrollmentFromEntityFromINumber(string entityCode, string iNumber);
        Task<Response<ChangeReport<Enrollment>>> CreateOrUpdateLmsEnrollments(List<EnrollmentRequest> enrollments);
        Task<Response<List<Enrollment>>> DeleteLmsEnrollments(List<EnrollmentRequest> deleteRequests);
        Task<Response<List<Enrollment>>> GetEnrollmentsFromCacheEntity(string system, string entityCode, List<string> roleNames);
        Task<Response<List<Enrollment>>> GetEnrollmentsFromCacheINumber(string system, string iNumber, List<string> roleNames);
        Task<Response<List<Enrollment>>> GetSisEnrollmentsForSection(string sectionCode);
        Task<Response<List<Enrollment>>> GetSisEnrollmentsFromINumber(string iNumber, List<string> roleNames, string sessionCode = null);
        Task<Response<List<Enrollment>>> CreateOrUpdateSisEnrollments(List<Enrollment> enrollments);
    }
}