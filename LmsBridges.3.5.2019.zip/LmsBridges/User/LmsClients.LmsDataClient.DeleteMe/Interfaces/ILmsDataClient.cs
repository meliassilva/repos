namespace Byui.LmsClients.LmsDataClient.Interfaces
{
    public interface ILmsDataClient : ISemester, IEnrollment, IEmail, IGrade, IUsers, IEntity
    {
    }
}
