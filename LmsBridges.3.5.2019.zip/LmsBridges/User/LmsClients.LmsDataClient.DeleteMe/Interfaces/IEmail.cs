﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LmsClients.LmsDataClient.Interfaces
{
    public interface IEmail
    {
        Task<Response<List<EmailTemplate>>> GetEmailTemplatesBySystem(string systemName);
        Task<Response<List<EmailTemplate>>> GetEmailTemplates(string systemName, string templateName);
        Task<Response<List<EmailTemplate>>> CreateEmailTemplate(EmailTemplate template);
        Task<Response<List<EmailTemplate>>> UpdateEmailTemplate(string systemName, string templateName, EmailTemplate template);
    }
}