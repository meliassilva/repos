﻿using System;
using Byui.LmsClients.LmsDataClient.Clients;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Byui.LmsClients.LmsDataClient.Interfaces;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Filters;
using Byui.LmsData.CommonObjects.Objects;
using MoreLinq;
using Newtonsoft.Json;

namespace Byui.LmsClients.LmsDataClient
{
    public class LmsDataClient : ILmsDataClient
    {
        // All of the "Business" Clients
        private readonly EnrollmentClient _enrClient;
        private readonly EntityClient _entClient;
        private readonly UserClient _usrClient;
        private readonly CacheClient _cchClient;
        private readonly SisClient _sisClient;
        private readonly AssignmentsClient _agnClient;
        private readonly EmailClient _emailClient;

        /// <summary>
        /// Connects to WSO2
        /// </summary>
        /// <param name="id"></param>
        /// <param name="secret"></param>
        /// <param name="url"></param>
        /// <param name="baseUrl"></param>
        public LmsDataClient(string id, string secret,string baseUrl=null)
        {
            var client = new BaseClient(id, secret,baseUrl);

            var apiClient = new ApiClient(client);

            _enrClient = new EnrollmentClient(apiClient);
            _entClient = new EntityClient(apiClient);
            _usrClient = new UserClient(apiClient);
            _cchClient = new CacheClient(apiClient);
            _sisClient = new SisClient(apiClient);
            _agnClient = new AssignmentsClient(apiClient);
        }

        public LmsDataClient(int port)
        {
            var client = new BaseClient(port);
            var apiClient = new ApiClient(client);

            _enrClient = new EnrollmentClient(apiClient);
            _entClient = new EntityClient(apiClient);
            _usrClient = new UserClient(apiClient);
            _cchClient = new CacheClient(apiClient);
            _sisClient = new SisClient(apiClient);
            _agnClient = new AssignmentsClient(apiClient);
            _emailClient = new EmailClient(apiClient);
        }

        #region LMS
        #region Enrollment
        public async Task<Response<List<Enrollment>>> SyncInstructorEnrollments(string entityCode) => await _enrClient.SyncInstructorEnrollments(entityCode);
        public async Task<Response<List<Enrollment>>> GetLmsEnrollmentsFromEntity(string entityCode, bool cacheBust) => await _enrClient.GetLmsEnrollmentsFromEntity(entityCode, cacheBust);

        public async Task<Dictionary<string, Response<List<Enrollment>>>> GetEnrollmentsFromEntityDetailed(string entityCode, bool cacheBust) => await _enrClient.GetEnrollmentsFromEntityDetailed(entityCode,cacheBust);

        public async Task<Response<List<Enrollment>>> GetLmsEnrollmentsFromINumber(string iNumber) => await _enrClient.GetLmsEnrollmentsFromINumber(iNumber);

        public async Task<Response<List<Enrollment>>> GetLmsEnrollmentFromEntityFromINumber(string entityCode, string iNumber) => await _enrClient.GetLmsEnrollmentFromEntityFromINumber(entityCode, iNumber);

        public async Task<Response<ChangeReport<Enrollment>>> CreateOrUpdateLmsEnrollments(List<EnrollmentRequest> enrollments) => await _enrClient.CreateOrUpdateLmsEnrollments(enrollments);

        public async Task<Response<List<Enrollment>>> DeleteLmsEnrollments(List<EnrollmentRequest> deleteRequests) => await _enrClient.DeleteLmsEnrollments(deleteRequests); 
        #endregion

        #region Entity
        public async Task<Response<List<Entity>>> GetLmsEntities(string semesterCode,bool cacheBust=false) => await _entClient.GetLmsEntities(semesterCode,cacheBust);

        public async Task<Response<List<Entity>>> GetLmsEntityFromCode(string entityCode) => await _entClient.GetLmsEntityByCode(entityCode);

        public async Task<Response<List<LmsData.CommonObjects.Objects.Entity>>> GetLmsEntitiesByCode(string entityCode) => await _entClient.GetLmsEntitiesByCode(entityCode);

        public async Task<Response<ChangeReport<Entity>>> CreateOrUpdateLmsEntities(List<Entity> entities) => await _entClient.CreateOrUpdateLmsEntities(entities);

        public Task<Response<List<SectionDetails>>> GetSisSections(string semesterCode)
        {
            throw new NotImplementedException();
        }

        public async Task<Response<List<SectionDetails>>> GetSectionDetails(SectionFilter sectionFilter)
        {
            var response = new Response<List<SectionDetails>>();
            try
            {
                if (sectionFilter.SectionCodes != null && sectionFilter.SectionCodes.Any())
                {
                    response.Errors.Add($"Filtering by section codes is not implemented!");
                }

                var sisSections = await GetSisSections(sectionFilter.SemesterCode,sectionFilter.CacheBust);
                var lmsSections = await _entClient.GetLmsSectionsForSemester(sectionFilter.SemesterCode);

                var lmsSectionsDict = lmsSections.Data.DistinctBy(x=>x.EntityCode).ToDictionary(x => x.EntityCode, x => x);
                sisSections.Data.ForEach(section =>
                {
                    if (lmsSectionsDict.ContainsKey(section.EntityCode))
                    {
                        var lmsSection = lmsSectionsDict[section.EntityCode];
                        if (lmsSection != null)
                        {
                            section.SystemEntityId = lmsSection.SystemEntityId;
                            section.SystemName += $",{lmsSection.SystemName}";
                        }
                    }
                });

                response.Data = sisSections.Data;
            }
            catch (Exception e)
            {
                response.Errors.Add($"{e.Message}");
            }

            return response;
        }

        public async Task<Response<List<Progress>>> GetCopyStatus(string copyProgressId) => await _entClient.GetCopyStatus(copyProgressId);

        public async Task<Response<ChangeReport<ContentMigration>>> CopyCourses(List<CopyRequest> copyRequests) => await _entClient.CopyCourses(copyRequests);

        public async Task<Response<List<string>>> DeleteLmsEntities(List<string> entityCodes) => await _entClient.DeleteLmsEntities(entityCodes);
        #endregion
        
        #region User
        public async Task<Response<List<User>>> GetUsers() => await _usrClient.GetUsers();
        
        public async Task<Response<ChangeReport<User>>> CreateOrUpdateUsers(List<User> users,string system) => await _usrClient.CreateOrUpdateUsers(users,system);

        public async Task<Response<List<User>>> GetUserFromINumber(string iNumber) => await _usrClient.GetUserFromINumber(iNumber);

        public async Task<Response<List<User>>> GetUsersInClassByEntity(string entityCode) => await _usrClient.GetUsersInClassByEntity(entityCode);

        #endregion
        #endregion

        #region Cache
        #region UserCache
        public async Task<Response<List<User>>> GetCacheUsers() => await _cchClient.GetCacheUsers();

        public async Task<Response<List<User>>> GetCacheUsers(List<string> iNumbers) => await _cchClient.GetCacheUsers(iNumbers);

        public async Task<Response<ChangeReport<User>>> CreateOrUpdateCacheUsers(List<User> users) => await _cchClient.CreateOrUpdateCacheUsers(users);
        #endregion

        #region EntityCache

        public async Task<Response<List<Entity>>> GetCacheEntity(string system, string entityCode) => await _cchClient.GetCacheEntity(system, entityCode);

        public async Task<Response<ChangeReport<Entity>>> CreateOrUpdateCacheEntities(List<Entity> entities) => await _cchClient.CreateOrUpdateCacheEntities(entities);
        #endregion

        #region EnrollmentCache
        public async Task<Response<List<Enrollment>>> GetEnrollmentsFromCacheEntity(string system, string entityCode, List<string> roleNames) => await _cchClient.GetEnrollmentsFromCacheEntity(system, entityCode, roleNames);

        public async Task<Response<List<Enrollment>>> GetEnrollmentsFromCacheINumber(string system, string iNumber, List<string> roleNames) => await _cchClient.GetEnrollmentsFromCacheINumber(system, iNumber, roleNames);

        public async Task<Response<List<User>>> GetUsersFromCacheEntity(string system, string entityCode, List<string> roleNames) => await _cchClient.GetUsersFromCacheEntity(system, entityCode, roleNames);
        #endregion
        #endregion

        #region Sis
        #region User
        public async Task<Response<List<User>>> GetSisUsers() => await _sisClient.GetSisUsers();
        public async Task<Response<List<User>>> GetSisUsersFromSemesterCode(string semesterCode,bool cacheBust) => await _sisClient.GetSisUsersFromSemesterCode(semesterCode,cacheBust);
        public async Task<Response<List<User>>> GetSisUserFromINumber(string iNumber) => await _sisClient.GetSisUserFromINumber(iNumber);
        #endregion

        #region Entity

        public async Task<Response<List<Entity>>> GetSisEntities(string semesterCode, bool cacheBust = false) =>
            await _sisClient.GetSisEntities(semesterCode, cacheBust = false);

        internal async Task<Response<List<SectionDetails>>> GetSisSections(string semesterCode,bool cacheBust = false)
        {
            var sections = new Response<List<SectionDetails>>();
            try
            {
                sections = await _sisClient.GetSisSections(semesterCode,cacheBust);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error writing file {e.Message}");
            }

            return sections;
        }

        #endregion

        #region Enrollment
        public async Task<Response<List<Enrollment>>> GetSisEnrollmentsForSection(string sectionCode) => await _sisClient.GetSisEnrollmentsForSection(sectionCode);

        public async Task<Response<List<Enrollment>>> GetSisEnrollmentsFromINumber(string iNumber, List<string> roleNames, string sessionCode) => await _sisClient.GetSisEnrollmentsFromINumber(iNumber, roleNames, sessionCode);

        public async Task<Response<List<Enrollment>>> CreateOrUpdateSisEnrollments(List<Enrollment> enrollments) => await _sisClient.CreateOrUpdateSisEnrollments(enrollments);
        #endregion

        #region Assignment
        public async Task<Response<List<Assignments>>> GetAssignmentsFromEntityCode(string entityCode) => await _agnClient.GetLmsAssignmentsFromEntity(entityCode);
        #endregion

        #region Grades
        public async Task<Response<List<SystemGrade>>> GetLmsFinalGrade(string entityCode) => await _usrClient.GetLmsFinalGrade(entityCode);

        public async Task<Response<List<SystemGrade>>> GetFinalGrades(string entityCode) => await _sisClient.GetFinalGrades(entityCode);
        
        public async Task<Response<List<SystemGrade>>> SetFinalGrades(List<SystemGrade> finalGrades, string submitterINumber) => await _sisClient.SetFinalGrades(finalGrades, submitterINumber);
        
        public async Task<Response<List<string>>> GetValidGradesForSection(string sectionCode) => await _sisClient.GetValidGradesForSection(sectionCode);
        
        #endregion

        #region Semester
        
        public async Task<Response<Semester>> GetSemesterForSection(string sectionCode) => await _sisClient.GetSemesterForSection(sectionCode);

        public async Task<Response<Semester>> GetCurrentSemester() => await _sisClient.GetCurrentSemester();
        
        public async Task<Response<Semester>> GetSemesterByDate(DateTime date) => await _sisClient.GetSemesterByDate(date);
        
        public async Task<Response<Semester>> GetPreviousSemester() => await _sisClient.GetPreviousSemester();
        
        public async Task<Response<Semester>> GetNextSemester() => await _sisClient.GetNextSemester();
        
        public async Task<Response<Semester>> GetFinalGradeSubmissionSemester() => await _sisClient.GetFinalGradeSubmissionSemester();
        
        #endregion
        #endregion

        #region Email

        public async Task<Response<List<EmailTemplate>>> GetEmailTemplatesBySystem(string systemName) => await _emailClient.GetEmailTemplatesBySystem(systemName);
        
        public async Task<Response<List<EmailTemplate>>> GetEmailTemplates(string systemName, string templateName) => await _emailClient.GetEmailTemplates(systemName, templateName);
        
        public async Task<Response<List<EmailTemplate>>> CreateEmailTemplate(EmailTemplate template) => await _emailClient.CreateEmailTemplate(template);
        
        public async Task<Response<List<EmailTemplate>>> UpdateEmailTemplate(string systemName, string templateName, EmailTemplate template) => await _emailClient.UpdateEmailTemplate(systemName, templateName, template);

        #endregion
    }
}
