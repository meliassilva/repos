﻿using AutoMapper;
using BridgeMonioring.Client;
using Byui.LmsClients.LmsDataClient;
using Byui.LMSDataBridges.Business.Business;
using Byui.LMSDataBridges.Business.Entities;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using Byui.LMSDataBridges.Enterprise.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Byui.LMSDataBridges.Business.Utilities
{
    public static class Configuration
    {
        public static void Configure(IServiceCollection services, IServiceConfiguration configuration)
        {
            ConfigureMapper();
            InitializeDependancyInjection(services, configuration);
        }

        private static void ConfigureMapper()
        {
            Mapper.Initialize(x =>
            {
            });
        }

        private static void InitializeDependancyInjection(IServiceCollection services, IServiceConfiguration configuration)
        {
            if (!string.IsNullOrEmpty(configuration.ConnectionString))
            {
                services.AddDbContext<LMSDataBridgesContext>(options => options.UseSqlServer(configuration.ConnectionString));
            }
            services.AddScoped<LmsDataClient>(client => new LmsDataClient(configuration.LmsDataClientId, configuration.LmsDataClientSecret, configuration.ApiBaseUrl));
            services.AddScoped<IClock, Clock>();
            services.AddScoped<UserBridgeBusiness>();
            services.AddScoped<StudentBusiness>();
            services.AddScoped<DevotionalBusiness>();
            services.AddScoped<TeacherBusiness>();
            services.AddScoped<UserCacheBusiness>();
            services.AddScoped<LmsDataClientTestingBusiness>();
            services.AddScoped<LoggingClient>(client => new LoggingClient(configuration.BridgeMonitoringApiUrl,"",""));
        }
    }
}
