﻿namespace Byui.LMSDataBridges.Business.Utilities
{
    public class Constants
    {
    }
}
