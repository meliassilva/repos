﻿using System.Collections.Generic;
using System.Linq;

namespace Byui.LMSDataBridges.Business.Utilities
{
    public static class Extensions
    {
        //public static IQueryable<SubItem> WithParentItem(this IQueryable<SubItem> item)
        //{
        //    return item.Include(i => i.ParentItem);
        //}

        public static List<T> Dequeue<T>(this Queue<T> queue, int numberToDequeue)
        {
            int dequeued = 0;
            var dequeuedList = new List<T>();
            while (queue.Any() && dequeued < numberToDequeue)
            {
                dequeued++;
                var nextItem = queue.Dequeue();
                dequeuedList.Add(nextItem);
            }

            return dequeuedList;
        }

        public static bool IsNullOrEmpty(this string str)
        {
            return string.IsNullOrEmpty(str);
        }
    }
}

