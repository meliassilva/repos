﻿using Microsoft.EntityFrameworkCore;

namespace Byui.LMSDataBridges.Business.Entities
{
    public class LMSDataBridgesContext : DbContext
    {

        public LMSDataBridgesContext(DbContextOptions<LMSDataBridgesContext> options) : base(options)
        {
            
        }
        
    }
}
