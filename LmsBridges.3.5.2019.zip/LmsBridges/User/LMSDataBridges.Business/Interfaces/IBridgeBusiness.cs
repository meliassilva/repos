﻿using System.Threading.Tasks;

namespace Byui.LMSDataBridges.Business.Interfaces
{
    public interface IBridgeBusiness
    {
        Task RunBridge();
    }
}
