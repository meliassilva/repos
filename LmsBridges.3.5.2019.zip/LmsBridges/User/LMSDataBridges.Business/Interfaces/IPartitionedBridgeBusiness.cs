﻿using System.Threading.Tasks;

namespace Byui.LMSDataBridges.Business.Interfaces
{
    public interface IPartitionedBridgeRepository
    {
        Task RunBridge(string runId);
    }
}
