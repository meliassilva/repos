﻿namespace Byui.LMSDataBridges.Business.Enums
{
    public enum SortDirection
    {
        Asc,
        Desc
    }
}
