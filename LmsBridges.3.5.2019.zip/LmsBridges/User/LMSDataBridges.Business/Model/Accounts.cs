﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Byui.LMSDataBridges.Business.Model
{
    public class Accounts
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("workflow_state")]
        public WorkflowState WorkflowState { get; set; }

        [JsonProperty("parent_account_id")]
        public long ParentAccountId { get; set; }

        [JsonProperty("root_account_id")]
        public long RootAccountId { get; set; }

        [JsonProperty("uuid")]
        public string Uuid { get; set; }

        [JsonProperty("default_storage_quota_mb")]
        public long DefaultStorageQuotaMb { get; set; }

        [JsonProperty("default_user_storage_quota_mb")]
        public long DefaultUserStorageQuotaMb { get; set; }

        [JsonProperty("default_group_storage_quota_mb")]
        public long DefaultGroupStorageQuotaMb { get; set; }

        [JsonProperty("default_time_zone")]
        public DefaultTimeZone DefaultTimeZone { get; set; }

        [JsonProperty("sis_account_id")]
        public string SisAccountId { get; set; }

        [JsonProperty("sis_import_id")]
        public long? SisImportId { get; set; }

        [JsonProperty("integration_id")]
        public object IntegrationId { get; set; }
    }

    public enum DefaultTimeZone { AmericaDenver };

    public enum WorkflowState { Active };
}
