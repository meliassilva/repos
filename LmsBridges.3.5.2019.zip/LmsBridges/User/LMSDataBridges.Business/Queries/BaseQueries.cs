﻿using Byui.LMSDataBridges.Business.Entities;

namespace Byui.LMSDataBridges.Business.Queries
{
    public abstract class BaseQueries
    {
        private readonly LMSDataBridgesContext _ctx;

        protected BaseQueries(LMSDataBridgesContext ctx)
        {
            _ctx = ctx;
        }
    }
}
