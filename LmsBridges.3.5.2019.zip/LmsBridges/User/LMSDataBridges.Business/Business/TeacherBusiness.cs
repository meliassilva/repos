﻿using Byui.LMSDataBridges.Enterprise.Interfaces;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using Byui.LmsData.CommonObjects.Objects;
using Byui.LmsData.CommonObjects;
using Byui.LMSDataBridges.Enterprise.Configuration;
using Byui.LmsClients.LmsDataClient;
using System.Linq;
using System.IO;
using Byui.LMSDataBridges.Business.Business;
using Byui.LMSDataBridges.Business.Interfaces;

namespace Byui.LMSDataBridges.Business.Business
{
    public class TeacherBusiness : IBridgeBusiness
    {
        private readonly IServiceConfiguration _configuration;

        public TeacherBusiness(IServiceConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Start the Teacher Enrollments Bridge (TEB)
        /// </summary>
        /// <returns></returns>
        public async Task RunBridge()
        {
            Entity entitiesSisInLms = new Entity();
            List<Exception> errorsRunningTeacherBridge = new List<Exception>();
            try
            {
                ////Remote Conneciton
                //LmsDataClient lmsClients = new LmsDataClient(_configuration.LmsDataClientId, _configuration.LmsDataClientSecret);

                //Local
                LmsDataClient lmsClients = new LmsDataClient(56665);
                //LmsDataClientMock lmsClientsMock = new LmsDataClientMock();

                //0. Get the actual or next semester
                string semesterCode = await GetSemesterToWork(lmsClients);

                var lmsEntitiesResponse = await lmsClients.GetLmsEntities(semesterCode);

                var entitiesToSync = lmsEntitiesResponse.Data.Where(x => x.Domain == "Online" || x.EntityCode.Contains("Pathway"))
                    .ToList();

                foreach (var entity in entitiesToSync)
                {
                    try
                    {
                        Console.WriteLine($"Syncing instructor for {entity.EntityCode} {entitiesToSync.IndexOf(entity)} of {entitiesToSync.Count}");
                        SyncInstructorEnrollmentInEntity(lmsClients,entity.EntityCode);
                    }
                    catch (Exception e)
                    {
                        errorsRunningTeacherBridge.Add(e);
                    }

                    ////1. Get Entities from SIS
                    ////Creating a response list with all actual entities from SIS
                    //Response<List<Entity>> listSisEntities = await lmsClients.GetSisEntities(semesterCode);

                    ////2. Get Entities from LMS
                    ////Creating a response list with all actual entities from LMS
                    //Response<List<Entity>> listLmsEntities = await lmsClients.GetLmsEntities(semesterCode);

                    ////2.a Sync Entities List (In LMS and Not In Lms)
                    ////Sis entities are in Lms entities
                    //var sectionsToSync = listSisEntities.Data.Where(x => !listLmsEntities.Data.All(y => y.EntityCode != x.EntityCode));

                    ////Sis entities are NOT in Lms entities
                    //var sectionsSisNotInLms = listSisEntities.Data.Where(x => listLmsEntities.Data.All(y => y.EntityCode != x.EntityCode));

                    ////3. Get Sis Enrollments From Entity
                    ////Creating a response list with all actual enrollments from SIS
                    //List<EnrollmentRequest> listSisEnrollments = await GetListSisEnrollments(lmsClients, sectionsToSync);

                    ////4. Get Lms Enrollments from Entity
                    ////Creating a response list with all actual enrollments from LMS
                    //List<EnrollmentRequest> listLmsEnrollments = await GetListLmsEnrollments(lmsClients, sectionsToSync, listSisEnrollments);

                    ////5. List with all enrollments to be added to Lms
                    //// Compare the both lists (SIS and LMS) and what doesn't contain in SIS, add to the list.
                    //List<EnrollmentRequest> lmsListToEnroll = GetListLmsToAdd(listSisEnrollments, listLmsEnrollments);

                    //List<string> test = new List<string>();
                    //foreach (var item in lmsListToEnroll)
                    //{
                    //    Console.WriteLine($"Inumber: {item.INumber},       Section: {item.SectionCode}");
                    //    test.Add($"Inumber: {item.INumber},               Section: {item.SectionCode}");
                    //}
                    //await File.WriteAllLinesAsync($"Z:\\Dan\\CanvasIntegration\\{semesterCode}", test);

                    ////6. Create or Update Lms Enrollments
                    //Response<ChangeReport<Enrollment>> PostResponse = await lmsClients.CreateOrUpdateLmsEnrollments(lmsListToEnroll);

                    ////7. List with all enrollments to be dropped from Lms
                    //// Compare the both lists (SIS and LMS) and what contains in LMS, but not in SIS, delete from the list.
                    //List<EnrollmentRequest> lmsListToDrop = GetListLmsToDrop(listSisEnrollments, listLmsEnrollments);

                    ////8. Delete Lms Enrollments
                    //Response<List<Enrollment>> DeleteResponse = await lmsClients.DeleteLmsEnrollments(lmsListToDrop);
                }
            }
            catch (Exception e)
            {
                errorsRunningTeacherBridge.Add(e);
            }
        }

        //*********************** Private methods for public methods above *****************************//

            /// <summary>
            /// Get the correct semester to work (current or next)
            /// </summary>
            /// <param name="lmsClients"></param>
            /// <returns></returns>
            private async Task<string> GetSemesterToWork(LmsDataClient lmsClients)
            {
                //Get current semester based on datatime.now
                var currentSemester = await lmsClients.GetCurrentSemester();

                //Get next semester based on datatime.now
                var nextSemester = await lmsClients.GetNextSemester();

                //Convert the semester Code to Current or Next based on the datetime.now
                var semesterCode = DateTime.Now > currentSemester.Data.EndDate ? ConvertToSemesterCode(nextSemester) : ConvertToSemesterCode(currentSemester);
                //hardcode - just for test
                //var semesterCode = "2018.Summer";
                return semesterCode;
            }

            /// <summary>
            /// Get the next semester code converting the data from GetNextSemester from lmsDataClient
            /// </summary>
            /// <param name="lmsClients"></param>
            /// <returns></returns>
            private static async Task<string> GetNextSemesterCode(LmsDataClient lmsClients)
            {
                var nextSemester = await lmsClients.GetNextSemester();
                var semesterName = nextSemester.Data.Name;
                var semesterYear = nextSemester.Data.Year;
                var semesterCode = $"{nextSemester.Data.Year}.{semesterName.Substring(0, semesterName.IndexOf(" "))}";
                return semesterCode;
            }

            /// <summary>
            /// Get an actual SIS enrollments list
            /// </summary>
            /// <param name="lmsDataClient"></param>
            /// <param name="listEntitiesToSync"></param>
            /// <returns></returns>
            private static async Task<List<EnrollmentRequest>> GetListSisEnrollments(LmsDataClient lmsDataClient,
                IEnumerable<Entity> listEntitiesToSync)
            {
                List<EnrollmentRequest> listSisEnrollments = new List<EnrollmentRequest>();
                //Empty list for the exceptions
                List<Exception> errorsSis = new List<Exception>();

                try
                {
                    foreach (var sisEntity in listEntitiesToSync)
                    {
                        var enrollmentsSis = await lmsDataClient.GetSisEnrollmentsForSection(sisEntity.EntityCode);
                        enrollmentsSis.Data =
                            enrollmentsSis.Data.Where(x => x.RoleName.ToLower() == "teacher")
                                .ToList(); //TODO this should be revisited later...
                        foreach (var enrollmentSis in enrollmentsSis.Data)
                        {
                            listSisEnrollments.Add(new EnrollmentRequest()
                            {
                                SectionCode = enrollmentSis.EntityCode,
                                INumber = enrollmentSis.UserINumber,
                                RoleName = enrollmentSis.RoleName
                            });
                        }
                    }
                }
                catch (Exception e)
                {
                    errorsSis.Add(e);
                }

                return listSisEnrollments;
            }

            /// <summary>
            /// Get an actual LMS enrollments list
            /// </summary>
            /// <param name="lmsDataClient"></param>
            /// <param name="listLmsEntities"></param>
            /// <param name="listSisEnrollments"></param>
            /// <returns>Objects list with all actual enrollments data for LMS</returns>
            private static async Task<List<EnrollmentRequest>> GetListLmsEnrollments(LmsDataClient lmsDataClient,
                IEnumerable<Entity> listEntitiesToSync, List<EnrollmentRequest> listSisEnrollments)
            {
                //Empty list to create the objects of enrollments on LMS
                List<EnrollmentRequest> listLmsEnrollments = new List<EnrollmentRequest>();

                //Empty list for the exceptions
                List<Exception> errorsLms = new List<Exception>();

                try
                {
                    foreach (var lmsEntity in listEntitiesToSync)
                    {
                        //If entityCode is NULL, skip
                        if (lmsEntity.EntityCode != null)
                        {
                            //Get Lms Enrollments by Entity passed
                            var enrollmentsLms =
                                await lmsDataClient.GetLmsEnrollmentsFromEntity(lmsEntity.EntityCode, true);

                            //For each enrollment in LMS
                            foreach (var enrollmentLms in enrollmentsLms.Data)
                            {
                                //Create an object with these data below and add to the list created above (first line)
                                listLmsEnrollments.Add(new EnrollmentRequest()
                                {
                                    SectionCode = enrollmentLms.EntityCode,
                                    INumber = enrollmentLms.UserINumber,
                                    RoleName = enrollmentLms.RoleName
                                });
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    errorsLms.Add(e);
                }

                //Return the list
                return listLmsEnrollments;
            }

            /// <summary>
            /// Get a LMS list to enroll/post
            /// </summary>
            /// <param name="listSisEnrollments"></param>
            /// <param name="listLmsEnrollments"></param>
            /// <returns>Objects list with all enrollments data to be done for LMS</returns>
            private static List<EnrollmentRequest> GetListLmsToAdd(List<EnrollmentRequest> listSisEnrollments,
                List<EnrollmentRequest> listLmsEnrollments)
            {
                //Empty list to be enrolled in LMS
                List<EnrollmentRequest> lmsListToEnroll = new List<EnrollmentRequest>();

                //Empty hashset to store the inumber and entity code (for fast purposes)
                var hashAddListOnLms = new HashSet<string>();

                //Adding to the hashset all inumbers + entitycode
                foreach (var lmsEnrollment in listLmsEnrollments)
                {
                    hashAddListOnLms.Add(lmsEnrollment.INumber + lmsEnrollment.SectionCode);
                }

                //If SIS enrollment not contains in hashset for LMS, add to the LMS list to enroll
                foreach (var sisEnrollment in listSisEnrollments)
                {
                    if (!hashAddListOnLms.Contains(sisEnrollment.INumber + sisEnrollment.SectionCode))
                    {
                        lmsListToEnroll.Add(sisEnrollment);
                    }
                }

                //Return the list
                return lmsListToEnroll;
            }

            /// <summary>
            /// Get a LMS list to be dropeed
            /// </summary>
            /// <param name="listSisEnrollments"></param>
            /// <param name="listLmsEnrollments"></param>
            /// <returns></returns>
            private static List<EnrollmentRequest> GetListLmsToDrop(List<EnrollmentRequest> listSisEnrollments,
                List<EnrollmentRequest> listLmsEnrollments)
            {
                // Empty list of LMS list to be dropped
                List<EnrollmentRequest> lmsListToDrop = new List<EnrollmentRequest>();

                var hashDelListOnLms = new HashSet<string>();

                foreach (var sisEnrollment in listSisEnrollments)
                {
                    hashDelListOnLms.Add(sisEnrollment.INumber + sisEnrollment.SectionCode);
                }

                foreach (var lmsEnrollment in listLmsEnrollments)
                {
                    if (!hashDelListOnLms.Contains(lmsEnrollment.INumber + lmsEnrollment.SectionCode))
                    {
                        lmsListToDrop.Add(lmsEnrollment);
                    }
                }

                return lmsListToDrop;
            }

            /// <summary>
            /// Convert the object Semester from getSemester (LmsDataClient) to semesterCode
            /// </summary>
            /// <param name="semester"></param>
            /// <returns>(e,g 2018.Spring)</returns>
            private string ConvertToSemesterCode(Response<Semester> semester)
            {
                var result = "";
                var _year = semester.Data.Name.Split(" ").LastOrDefault();
                var _sessionName = semester.Data.Name.Substring(0, semester.Data.Name.IndexOf(" "));
                result = $"{_year}.{_sessionName}";
                return result;
            }

        private void SyncInstructorEnrollmentInEntity(LmsDataClient lmsDataClient, string entityCode)
        {
            var syncResult = lmsDataClient.SyncInstructorEnrollments(entityCode).Result;
        }
    }

    }
