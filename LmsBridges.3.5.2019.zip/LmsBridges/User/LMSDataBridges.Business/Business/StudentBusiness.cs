﻿using Byui.LMSDataBridges.Enterprise.Interfaces;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Diagnostics;
using Byui.LmsData.CommonObjects.Objects;
using Byui.LmsData.CommonObjects;
using Byui.LMSDataBridges.Enterprise.Configuration;
using Byui.LmsClients.LmsDataClient;
using System.Linq;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using BridgeMonioring.Client;
using Byui.BridgeMonitoring.Enterprise.Models;
using Byui.LMSDataBridges.Business.Business;
using MoreLinq;
using Newtonsoft.Json;

namespace Byui.LMSDataBridges.Business.Business
{
    public class StudentBusiness : IPartitionedBridgeBusiness<Enrollment>
    {
        private readonly LmsDataClient _lmsClient;
        private readonly string _studentEnrollmentBridgeSetWindowTitlePrefix = "Student Enrollment Bridge Set";

        public StudentBusiness(LmsDataClient lmsDataClient)
        {
            _lmsClient = lmsDataClient;
        }


        public async Task ConfigureSectionLists(int numberOfLists)
        {
            var sectionsToSkip = new List<string> {"Campus.2018.Fall.FDSCI 209.1"};
            //Local
            //LmsDataClient _lmsClient = new LmsDataClient(56665);

            //0. Get the actual or next semester
            string semesterCode = await GetSemesterToWork(_lmsClient);
            Console.WriteLine($" - Running for {semesterCode} Semester");

            //1. Get Entities from SIS
            //Creating a response list with all actual entities from SIS
            Response<List<Entity>> sisEntities = await _lmsClient.GetSisEntities(semesterCode,true);
            var daBiz = sisEntities.Data.Where(x => x.EntityCode.Contains("Campus.2018.Fall.B 302.")).ToList();
            Console.WriteLine($" # {sisEntities.Data.Count} SIS Sections in this semester");

            //2. Get Entities from LMS
            //Creating a response list with all actual entities from LMS
            //Response<List<Entity>> listLmsEntities = await _lmsClient.GetLmsEntities(semesterCode,false);
           // Console.WriteLine($" # {listLmsEntities.Data.Count} LMS Sections in this semester");

            //2.a Sync Entities List (In LMS and Not In Lms)
            //Sis entities are in Lms entities
            //var allSectionsToSync = sisEntities.Data.Where(x => !listLmsEntities.Data.All(y => y.EntityCode != x.EntityCode));
            var allSectionsToSync = sisEntities.Data.Where(section=>section.EntityCode.Split('.').Length == 5).Where(x=>!x.EntityCode.ToLower().Contains("pathway")).ToList();
            var sectionCodeGroups = allSectionsToSync.Select((item, index) => new { index, item })
                .GroupBy(x => x.index % numberOfLists)
                .Select(x => x.Select(y => y.item)).DistinctBy(x=>x).ToList();

            if (!Directory.Exists("section-sets"))
            {
                Directory.CreateDirectory("section-sets");
            }

            var sectionSetNumber = 1;
            foreach (var sectionCodeGroup in sectionCodeGroups)
            {
                var fileName = $"section-sets/section-set-{sectionSetNumber++}.txt";
                File.WriteAllLines(fileName,sectionCodeGroup.Where(x=> ! sectionsToSkip.Contains(x.EntityCode)).Select(x=>$"{x.EntityCode}").ToList());
            }

            var runJobsFileContent = new List<string>();
            for (var x = 1; x <= numberOfLists; x++)
            {
                runJobsFileContent.Add($"START \"{_studentEnrollmentBridgeSetWindowTitlePrefix} {x}\" dotnet LmsBridges.Console.dll SEB {x}");
                runJobsFileContent.Add("TIMEOUT 1");
                //runJobsFileContent.Add($"START dotnet LmsBridges.Console.dll INST {x}");
            }
            runJobsFileContent.Add($"START dotnet LmsBridges.Console.dll SEB 404");
            runJobsFileContent.Add("TIMEOUT 1");
            runJobsFileContent.Add($"START dotnet LmsBridges.Console.dll SEB 500");
            runJobsFileContent.Add("TIMEOUT 1");
            File.WriteAllLines("runJobs.bat",runJobsFileContent);

            Console.WriteLine($" # {allSectionsToSync.Count()} Sections to be synced/bridged in this semester\n");
        }
        /// <summary>
        /// Start the Student Enrollments Bridge (SEB)
        /// </summary>
        /// <returns></returns>
        public async Task<Response<ChangeReport<Enrollment>>> RunBridge(string sectionListSetNumber, LoggingClient logger)
        {
            
            var sectionsWithInstructors = new List<string>();
            var fileName = $"section-sets/section-set-{sectionListSetNumber}.txt";
            var sectionsToSync = File.ReadAllLines(fileName).ToList();

            var globalResponse = new Response<ChangeReport<Enrollment>> { Data = new ChangeReport<Enrollment>() };

            Console.WriteLine($"#############   Student Enrollments Bridge  ###############\n");
            Entity entitiesSisInLms = new Entity();
            List<Exception> errorsRunningStudentBridge = new List<Exception>();

            if (IsSectionSetRunning(sectionListSetNumber))
            {
                var info = new BridgeReportInitiation();
                info.Classification = "Lms";
                info.Category = "Enrollment";
                info.Subcategory = "Student";
                info.Instance = $"Section Set {sectionListSetNumber}";
                var daUrl = logger.GetUrl();
                var daJson = JsonConvert.SerializeObject(info);
                var bridgeStartInfo = logger.BridgeRunStart(info).Result;

                globalResponse.Errors.Add($"Section set {sectionListSetNumber} is all ready running!");
                BridgeReportConclusion<object> bco = new BridgeReportConclusion<object> { ChangeReport = new ChangeReport<object>() };
                bco.Errors = globalResponse.Errors;
                bco.ChangeReport.Added = globalResponse.Data.Added.Select(x => (object)x).ToList();
                bco.ChangeReport.Deleted = globalResponse.Data.Deleted.Select(x => (object)x).ToList();
                
                bco.Id = bridgeStartInfo.Data;
                var bridgeTask = logger.BridgeRunComplete(bco);
                Task.WaitAll(new List<Task> { bridgeTask }.ToArray());
                return globalResponse;
            }
            try
            {
                var index = 0;
                
                foreach (var sectionToSync in sectionsToSync)
                {
                    Console.WriteLine("------------------------------------------------------------------------");

                    var response = new Response<ChangeReport<Enrollment>> { Data = new ChangeReport<Enrollment>() };
                    var info = new BridgeReportInitiation();
                    info.Classification = "Lms";
                    info.Category = "Enrollment";
                    info.Subcategory = "Student";
                    info.Instance = $"{sectionToSync}";
                    var daUrl = logger.GetUrl();
                    var daJson = JsonConvert.SerializeObject(info);
                    var bridgeStartInfo = logger.BridgeRunStart(info).Result;
                    System.Console.WriteLine($"{bridgeStartInfo}");
                    if (sectionToSync == null)
                    {
                        break;
                    }

                    Console.WriteLine($"Evaluating: {sectionToSync} {index++} of {sectionsToSync.Count}");
                    //Sis entities are NOT in Lms entities
                    //var sectionsSisNotInLms = sisEntities.Data.Where(x => listLmsEntities.Data.All(y => y.EntityCode != x.EntityCode));
                    Response<List<Entity>> lmsEntity = new Response<List<Entity>>();
                    try
                    {
                        lmsEntity = await _lmsClient.GetLmsEntityFromCode(sectionToSync);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine($"Error reading section {sectionToSync}");
                    }

                    if (lmsEntity?.Data == null)
                    {
                        BridgeReportConclusion<object> bco1 = new BridgeReportConclusion<object> { ChangeReport = new ChangeReport<object>() };
                        bco1.Errors = response.Errors;
                        bco1.Warnings.Add($"LMS Entity {sectionToSync} Not Found");
                        bco1.Id = bridgeStartInfo.Data;
                        var bridgeTask1 = logger.BridgeRunComplete(bco1);
                        Task.WaitAll(new List<Task> { bridgeTask1 }.ToArray());
                        continue;
                    }

                    if (!lmsEntity.Data.Any())
                    {
                        BridgeReportConclusion<object> bco1 = new BridgeReportConclusion<object> { ChangeReport = new ChangeReport<object>() };
                        bco1.Errors = response.Errors;
                        bco1.Warnings.Add($"LMS Entity {sectionToSync} Not Found");
                        bco1.Id = bridgeStartInfo.Data;
                        var bridgeTask1 = logger.BridgeRunComplete(bco1);
                        Task.WaitAll(new List<Task> { bridgeTask1 }.ToArray());
                        continue;
                    }

                    try
                    {
                        //3. Get Sis Enrollments From Entity
                        //Creating a response list with all actual enrollments from SIS
                        List<EnrollmentRequest> sisEnrollments =
                            await GetListSisEnrollments(_lmsClient, new List<string> {sectionToSync});
                        if (sisEnrollments.Count == 0)
                        {
                            //TODO throw exception and handling...
                            Console.WriteLine($"Section does not appear to have SIS enrollments, skipping...");
                            continue;
                        }
                        var carysEnrollment = sisEnrollments.Where(x => x.INumber.Contains("LBC0121355")).FirstOrDefault();
                        var ldsBcEnrollments = sisEnrollments.Where(x => x.INumber.Contains("LBC")).ToList();
                            
                        Console.WriteLine($" # {sisEnrollments.Count()} SIS Enrollments in this semester");

                        //4. Get Lms Enrollments from Entity
                        //Creating a response list with all actual enrollments from LMS
                        List<EnrollmentRequest> lmsEnrollments =
                            await GetListLmsEnrollments(_lmsClient, new List<string> {sectionToSync});
                        var lbcLmsEnrollments = lmsEnrollments.Where(x => x.INumber != null && x.INumber.ToLower().Contains("lbc")).ToList();
                        var nullINumberEnrollments = lmsEnrollments.Where(x => x.INumber == null).ToList();
                        Console.WriteLine($"There are {lbcLmsEnrollments.Count} LDS BC Enrollments and {nullINumberEnrollments.Count} null INumber enrollments in the LMS.");
                        var instructorEnrollment =
                            lmsEnrollments.FirstOrDefault(x =>
                                x.RoleName.ToLower() == "teacher" || x.RoleName.ToLower() == "instructor");
                        if (instructorEnrollment != null)
                        {
                            sectionsWithInstructors.Add(sectionToSync);
                        }

                        Console.WriteLine($" # {lmsEnrollments.Count()} LMS Enrollments in this semester");

                        //5. List with all enrollments to be added to Lms
                        // Compare the both lists (SIS and LMS) and what doesn't contain in SIS, add to the list.
                        List<EnrollmentRequest> lmsEnrollmentRequests =
                            GetLmsEnrollmentsToAdd(sisEnrollments, lmsEnrollments);

                        //lmsEnrollmentRequests = lmsEnrollmentRequests
                        //    .Where(request =>
                        //        request.RoleName.ToLower() == "student" && !request.INumber.ToLower().Contains("lbc"))
                        //    .ToList();

                        lmsEnrollmentRequests = lmsEnrollmentRequests
                            .Where(request =>
                                request.RoleName.ToLower() == "student")
                            .ToList();


                        Console.WriteLine(
                            $" # {lmsEnrollmentRequests.Count()} Enrollments TO BE ADDED in this semester");
                        //6. Create or Update Lms Enrollments
                        foreach (var enrollmentRequest in lmsEnrollmentRequests)
                        {
                            try
                            {
                                var lmsUserResponse = await _lmsClient.GetUserFromINumber(enrollmentRequest.INumber);
                                if (lmsUserResponse.Errors.Any())
                                {
                                    var sisUserResponse =
                                        await _lmsClient.GetSisUserFromINumber(enrollmentRequest.INumber);
                                    if (!sisUserResponse.Errors.Any())
                                    {
                                        var newbie = sisUserResponse.Data.FirstOrDefault();

                                        if (newbie != null)
                                        {
                                            Console.WriteLine(
                                                $"\tCreating user {newbie.UserFirst} {newbie.UserLast} {newbie.UserEmail} {newbie.UserINumber}");
                                            var newUserResponse = _lmsClient
                                                .CreateOrUpdateUsers(sisUserResponse.Data, "Canvas")
                                                .Result; //TODO resolve system
                                            //int milliseconds = 1000;
                                            //Thread.Sleep(milliseconds);
                                            Console.WriteLine(
                                                $"\t\t{newUserResponse.Errors.Count} Errors creating user");
                                        }
                                    }
                                }

                                Response<ChangeReport<Enrollment>> PostResponse =
                                    await _lmsClient.CreateOrUpdateLmsEnrollments(
                                        new List<EnrollmentRequest> {enrollmentRequest});
                                if (PostResponse?.Data?.Added != null && PostResponse.Data.Added.Any())
                                {
                                    response.Data.Added.AddRange(PostResponse.Data.Added);
                                }

                                if (PostResponse.Errors != null && PostResponse.Errors.Any())
                                {
                                    response.Errors.AddRange(PostResponse.Errors);
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine($"Error: {e.Message}");
                            }

                        }

                        //7. List with all enrollments to be dropped from Lms
                        // Compare the both lists (SIS and LMS) and what contains in LMS, but not in SIS, delete from the list.

                        var caryLmsEnrollment = lmsEnrollments.Where(x => x.INumber != null && x.INumber.Contains("LBC0121355")).FirstOrDefault();
                        var ldsBcLmsEnrollments = lmsEnrollments.Where(x => x.INumber != null && x.INumber.Contains("LBC") && !x.INumber.Contains("OLD-")).ToList();

                        List<EnrollmentRequest> lmsEnrollmentsToDrop =
                            GetLmsEnrollmentsToDrop(sisEnrollments, lmsEnrollments);

                        //8. Delete Lms Enrollments
                        lmsEnrollmentsToDrop = lmsEnrollmentsToDrop.Where(request =>
                            !string.IsNullOrEmpty(request.INumber) && request.RoleName.ToLower() == "student" && !request.INumber.Contains("OLD-")).ToList();

                        //var harknessEnrollments = lmsEnrollments.Where(x => x.INumber == null || x.INumber.Contains("LBC0096730")).ToList();
                        //Console.WriteLine($"Harkness has {harknessEnrollments.Count} enrollments");

                        Console.WriteLine(
                            $" # {lmsEnrollmentsToDrop.Count()} Enrollments TO BE DROPPED in this semester");
                        var DeleteResponse = await _lmsClient.DeleteLmsEnrollments(lmsEnrollmentsToDrop);
                        if (DeleteResponse.Data != null && DeleteResponse.Data.Any())
                        {
                            List<Enrollment> deleted = DeleteResponse?.Data.ToList();
                            response.Data.Deleted.AddRange(deleted);
                        }

                        if (DeleteResponse?.Errors != null && DeleteResponse.Errors.Any())
                        {
                            response.Errors.AddRange(DeleteResponse.Errors);
                            Console.WriteLine($"{DeleteResponse.Errors.Count} errors deleting");
                        }
                    }
                    catch (Exception e)
                    {
                        response.Errors.Add(e.Message);
                    }

                    //var sectionsWithInstructorsFileName =
                    //    $"section-sets/section-set-with-instructor-{sectionListSetNumber}.txt";
                    //File.WriteAllLines(sectionsWithInstructorsFileName, sectionsWithInstructors);
                    BridgeReportConclusion<object> bco = new BridgeReportConclusion<object> { ChangeReport = new ChangeReport<object>() };
                    bco.Errors = response.Errors;
                    bco.ChangeReport.Added = response.Data.Added.Select(x => (object)x).ToList();
                    bco.ChangeReport.Deleted = response.Data.Deleted.Select(x => (object)x).ToList();

                    bco.Id = bridgeStartInfo.Data;
                    var bridgeTask = logger.BridgeRunComplete(bco);
                    Task.WaitAll(new List<Task> { bridgeTask }.ToArray());

                    Console.WriteLine("********************************************************************************");

                }
            }
            catch (Exception e)
            {
                globalResponse.Errors.Add(e.Message);
            }

             return globalResponse;
        }

        private bool IsSectionSetRunning(string sectionListSetNumber)
        {
            var proccesses = Process.GetProcesses();
            if (proccesses.Any(x => x.MainWindowTitle == $"{_studentEnrollmentBridgeSetWindowTitlePrefix} {sectionListSetNumber}" && x.Id != Process.GetCurrentProcess()?.Id))
            {
                Console.WriteLine("Process is already running!");
                return true;
            }

            return false;
        }

        public async Task SyncInstructors(int sectionListSetNumber)
        {
            var sectionsWithInstructors = new List<string>();
            var fileName = $"section-sets/section-set-{sectionListSetNumber}.txt";
            var sectionsToSync = File.ReadAllLines(fileName).ToList();

            Console.WriteLine($"#############   Student Enrollments Bridge  ###############\n");
            Entity entitiesSisInLms = new Entity();
            List<Exception> errorsRunningStudentBridge = new List<Exception>();
            try
            {

                var index = 0;

                foreach (var sectionToSync in sectionsToSync)
                {
                    if (sectionToSync == null)
                    {
                        break;
                    }

                    Console.WriteLine($"--------------------------------------------------------------------------");
                    Console.WriteLine($"Evaluating: {sectionToSync} {index++} of {sectionsToSync.Count}");
                    //Sis entities are NOT in Lms entities
                    //var sectionsSisNotInLms = sisEntities.Data.Where(x => listLmsEntities.Data.All(y => y.EntityCode != x.EntityCode));
                    Response<List<Entity>> lmsEntity = new Response<List<Entity>>();
                    try
                    {
                        lmsEntity = await _lmsClient.GetLmsEntityFromCode(sectionToSync);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine($"Error reading section {sectionToSync}");
                    }

                    if (lmsEntity?.Data == null)
                    {
                        continue;
                    }

                    if (!lmsEntity.Data.Any())
                    {
                        continue;
                    }

                    lmsEntity.Data = lmsEntity.Data.Where(x => x.SystemName.ToLower() != "canvas").ToList();

                    if (!lmsEntity.Data.Any())
                    {
                        continue;
                    }
                    var syncResult = await _lmsClient.SyncInstructorEnrollments(sectionToSync);
                    Console.WriteLine($"{syncResult.Errors.Count} errors");

                    Console.WriteLine($"*********************************************************");
                }

                var sectionsWithInstructorsFileName = $"section-sets/section-set-with-instructor-{sectionListSetNumber}.txt";
                File.WriteAllLines(sectionsWithInstructorsFileName, sectionsWithInstructors);
            }
            catch (Exception e)
            {
                errorsRunningStudentBridge.Add(e);
            }
        }

        //*********************** Private methods for public methods above *****************************//

        /// <summary>
        /// Get the correct semester to work (current or next)
        /// </summary>
        /// <param name="lmsClients"></param>
        /// <returns></returns>
        private async Task<string> GetSemesterToWork(LmsDataClient lmsClients)
        {
            //Get current semester based on datatime.now
            var currentSemester = await lmsClients.GetCurrentSemester();

            //Get next semester based on datatime.now
            var nextSemester = await lmsClients.GetNextSemester();

            //Convert the semester Code to Current or Next based on the datetime.now
            if (currentSemester == null)
            {
                currentSemester = nextSemester;
            }

            var semesterCode = DateTime.Now > nextSemester.Data.StartDate.AddDays(-14) ? ConvertToSemesterCode(nextSemester) : ConvertToSemesterCode(currentSemester);
            ////hardcode - just for test
            //var semesterCode = "2018.Summer";
            return semesterCode;
        }

        /// <summary>
        /// Get the next semester code converting the data from GetNextSemester from lmsDataClient
        /// </summary>
        /// <param name="lmsClients"></param>
        /// <returns></returns>
        private static async Task<string> GetNextSemesterCode(LmsDataClient lmsClients)
        {
            var nextSemester = await lmsClients.GetNextSemester();
            var semesterName = nextSemester.Data.Name;
            var semesterYear = nextSemester.Data.Year;
            var semesterCode = $"{nextSemester.Data.Year}.{semesterName.Substring(0, semesterName.IndexOf(" "))}";
            return semesterCode;
        }

        /// <summary>
        /// Get an actual SIS enrollments list
        /// </summary>
        /// <param name="lmsDataClient"></param>
        /// <param name="listEntitiesToSync"></param>
        /// <returns></returns>
        private static async Task<List<EnrollmentRequest>> GetListSisEnrollments(LmsDataClient lmsDataClient, List<string> entityCodesToSync)
        {
            List<EnrollmentRequest> listSisEnrollments = new List<EnrollmentRequest>();
            //Empty list for the exceptions
            List<Exception> errorsSis = new List<Exception>();

            try
            {
                foreach (var sisEntity in entityCodesToSync)
                {

                    var enrollmentsSis = await lmsDataClient.GetSisEnrollmentsForSection(sisEntity);

                    foreach (var enrollmentSis in enrollmentsSis.Data)
                    {
                        listSisEnrollments.Add(new EnrollmentRequest()
                        {
                            SectionCode = enrollmentSis.EntityCode,
                            INumber = enrollmentSis.UserINumber,
                            RoleName = enrollmentSis.RoleName
                        });
                    }
                }
            }
            catch (Exception e)
            {
                errorsSis.Add(e);
            }
            return listSisEnrollments;
        }

        /// <summary>
        /// Get an actual LMS enrollments list
        /// </summary>
        /// <param name="lmsDataClient"></param>
        /// <param name="listLmsEntities"></param>
        /// <param name="listSisEnrollments"></param>
        /// <returns>Objects list with all actual enrollments data for LMS</returns>
        private static async Task<List<EnrollmentRequest>> GetListLmsEnrollments(LmsDataClient lmsDataClient, List<string> entityCodesToSync)
        {
            //Empty list to create the objects of enrollments on LMS
            List<EnrollmentRequest> listLmsEnrollments = new List<EnrollmentRequest>();

            //Empty list for the exceptions
            List<Exception> errorsLms = new List<Exception>();

            try
            {
                foreach (var entityCode in entityCodesToSync)
                {
                    //Get Lms Enrollments by Entity passed
                    var enrollmentsLms = await lmsDataClient.GetLmsEnrollmentsFromEntity(entityCode,true);
                    var lmsSystems = enrollmentsLms.Data.Select(x => x.SystemName).Distinct().ToList();
                    if (lmsSystems.Count > 1)
                    {
                        Console.WriteLine($"Appears to be more than one lms, only syncing Canvas...");
                        enrollmentsLms.Data = enrollmentsLms.Data.Where(x => x.SystemName == "Canvas").ToList();
                    }

                    //For each enrollment in LMS
                    foreach (var enrollmentLms in enrollmentsLms.Data)
                    {
                        //if (enrollmentLms.RoleName.ToUpper().Contains("STUDENT"))
                       // {
                            //Create an object with these data below and add to the list created above (first line)
                            listLmsEnrollments.Add(new EnrollmentRequest()
                            {
                                SectionCode = enrollmentLms.EntityCode,
                                INumber = enrollmentLms.UserINumber,
                                RoleName = enrollmentLms.RoleName
                            });
                        //}
                    }
                }
            }
            catch (Exception e)
            {
                errorsLms.Add(e);
            }

            //Return the list
            return listLmsEnrollments;
        }

        /// <summary>
        /// Get a LMS list to enroll/post
        /// </summary>
        /// <param name="sisEnrollments"></param>
        /// <param name="lmsEnrollments"></param>
        /// <returns>Objects list with all enrollments data to be done for LMS</returns>
        private static List<EnrollmentRequest> GetLmsEnrollmentsToAdd(List<EnrollmentRequest> sisEnrollments, List<EnrollmentRequest> lmsEnrollments)
        {
            return sisEnrollments.Where(x => lmsEnrollments.All(y => y?.INumber?.ToLower() != x?.INumber?.ToLower())).ToList();
            //Empty list to be enrolled in LMS
            List<EnrollmentRequest> lmsListToEnroll = new List<EnrollmentRequest>();

            //Empty hashset to store the inumber and entity code (for fast purposes)
            var hashAddListOnLms = new HashSet<string>();

            //Adding to the hashset all inumbers + entitycode
            foreach (var lmsEnrollment in lmsEnrollments)
            {
                hashAddListOnLms.Add(lmsEnrollment.INumber + lmsEnrollment.SectionCode);
            }

            //If SIS enrollment not contains in hashset for LMS, add to the LMS list to enroll
            foreach (var sisEnrollment in sisEnrollments)
            {
                if (!hashAddListOnLms.Contains(sisEnrollment.INumber + sisEnrollment.SectionCode))
                {
                    lmsListToEnroll.Add(sisEnrollment);
                }
            }

            //Return the list
            return lmsListToEnroll;
        }

        /// <summary>
        /// Get a LMS list to be dropeed
        /// </summary>
        /// <param name="listSisEnrollments"></param>
        /// <param name="listLmsEnrollments"></param>
        /// <returns></returns>
        private static List<EnrollmentRequest> GetLmsEnrollmentsToDrop(List<EnrollmentRequest> listSisEnrollments, List<EnrollmentRequest> listLmsEnrollments)
        {
            return listLmsEnrollments.Where(x => listSisEnrollments.All(y => y.INumber != x.INumber)).ToList();
            // Empty list of LMS list to be dropped
            List<EnrollmentRequest> lmsListToDrop = new List<EnrollmentRequest>();

            var hashDelListOnLms = new HashSet<string>();

            foreach (var sisEnrollment in listSisEnrollments)
            {
                hashDelListOnLms.Add(sisEnrollment.INumber + sisEnrollment.SectionCode);
            }

            foreach (var lmsEnrollment in listLmsEnrollments)
            {
                if (!hashDelListOnLms.Contains(lmsEnrollment.INumber + lmsEnrollment.SectionCode))
                {
                    lmsListToDrop.Add(lmsEnrollment);
                }
            }

            return lmsListToDrop;
        }

        /// <summary>
        /// Convert the object Semester from getSemester (LmsDataClient) to semesterCode
        /// </summary>
        /// <param name="semester"></param>
        /// <returns>(e,g 2018.Spring)</returns>
        private string ConvertToSemesterCode(Response<Semester> semester)
        {
            var result = "";
            var _year = semester.Data.Name.Split(" ").LastOrDefault();
            var _sessionName = semester.Data.Name.Substring(0, semester.Data.Name.IndexOf(" "));
            result = $"{_year}.{_sessionName}";
            return result;
        }

        public Task<Response<ChangeReport<Enrollment>>> RunBridge(string runId)
        {
            throw new NotImplementedException();
        }
    }
}