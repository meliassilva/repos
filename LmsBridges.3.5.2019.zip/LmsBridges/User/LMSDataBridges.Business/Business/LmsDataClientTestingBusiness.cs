﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Byui.LmsClients.LmsDataClient;
using Byui.LmsClients.LmsDataClient.Interfaces;
using Byui.LmsData.CommonObjects.Objects;
using Byui.LMSDataBridges.Business.Utilities;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using Newtonsoft.Json;

namespace Byui.LMSDataBridges.Business.Business
{
    public class LmsDataClientTestingBusiness
    {
        private const int BATCH_SIZE = 3000;
        private readonly ILmsDataClient _lmsDataClient;
        private readonly ITeacherBusiness _teacherBusiness;

        public LmsDataClientTestingBusiness(ILmsDataClient lmsDataClient, ITeacherBusiness teacherBusiness)
        {
            _teacherBusiness = teacherBusiness;
            _lmsDataClient = lmsDataClient;
        }

        public async Task Test()
        {
            bool run = true;
            while (run)
            {
                var entityCode = "Online.2018.Spring.PSYCH 111.8";
                var iNumber = "472650977";
                var systemName = "Final Grade Submit";
                var roles = new List<string>
                {
                    "Student",
                    "Teacher"
                };

                try
                {
                    //await GetLmsEntityFromCode(entityCode);
                    var sisGrades = await GetSisFinalGrades(entityCode);
                    var lmsGrades = await GetLmsFinalGrades(entityCode);
                    var sisUsersMissingFromLms = CalculateSisUsersMissingFromLms(sisGrades, lmsGrades);
                    var lmsUsersMissingFromSis = CalculateLmsUsersMissingFromSis(sisGrades, lmsGrades);
                    //await GetUserFromINumber(iNumber);
                    //await GetValidGradesForSection(entityCode);
                    //await GetSisEnrollmentsFromINumber(iNumber, roles);
                    //await GetSemesterForSection(entityCode);

                    //await SetFinalGrades(new List<SystemGrade>(),iNumber);

                    //await GetEmailTemplatesBySystem(systemName);
                    //await UpdateEmailTemplate("SystemName", "templateName", new EmailTemplate());


                }
                catch (Exception e)
                {
                    Console.WriteLine(e);

                }
            }

        }

        public async Task CheckSisVsLmsEnrollments(string semesterCode = "2018.Spring")
        {
           // Response<List<Entity>> entitiesResponse = await _lmsDataClient.GetSisEntities(semesterCode); //TODO need to get this endpoint fixed...
            var entitiesJson = File.ReadAllText("entities-response.json");
            var sectionsOfInterest = File.ReadAllLines("sections-of-interest.txt");

            var entities = JsonConvert.DeserializeObject<List<Entity>>(entitiesJson);

            var allentityCodes = entities.Select(x => x.EntityCode).ToList();
            File.WriteAllLines("allEntityCodes.txt",allentityCodes);

            if (sectionsOfInterest.Any()) {
                entities = entities.Where(entity => sectionsOfInterest.Contains(entity.EntityCode)).ToList();
            }

            var entityCodes = entities.Where(entity=>entity.EntityType == "Section").Select(entity => entity.EntityCode).Distinct().ToList();
            entityCodes = entityCodes.Take(100).ToList();

            var filePath = $"EntityGradeReport-{String.Format("0:yyyy-MM-dd_hh-mm-ss-tt", DateTime.Now.ToString())}.csv";
            var fileLines = new List<string> { "EntityCode,Sis Grade Count,Lms Grade Count,Sis Participated Problem Count,Sis Grades Missing,Lms Missing Grades,LDS BC Grades,Sis Users Missing From Lms,Lms Users Missing From Sis,Class likely not in LMS,Class likely missing from SIS" };
            foreach (var entityCode in entityCodes)
            {
                try
                {
                    var sisGrades = await GetSisFinalGrades(entityCode);
                    var brokenGrades = sisGrades.
                        Where(grade => grade.LetterGrade == "F" && grade.ParticipatedInClass == null).ToList();
                    var sisMissingGrades = sisGrades.Where(grade => grade.LetterGrade.IsNullOrEmpty()).ToList();

                    var lmsGrades = await GetLmsFinalGrades(entityCode);
                    var missingGrades = lmsGrades.Where(grade => grade.LetterGrade.IsNullOrEmpty()).ToList();
                    var ldsBcGrades = lmsGrades.Where(grade => grade.UserINumber.Contains("LBC")).ToList();

                    var sisUsersMissingFromLms = CalculateSisUsersMissingFromLms(sisGrades, lmsGrades);
                    var lmsUsersMissingFromSis = CalculateLmsUsersMissingFromSis(sisGrades, lmsGrades);
                    fileLines.Add($"{entityCode},{sisGrades.Count},{lmsGrades.Count},{brokenGrades.Count},{sisMissingGrades.Count},{missingGrades.Count},{ldsBcGrades.Count},{sisUsersMissingFromLms.Count},{lmsUsersMissingFromSis.Count},{(sisGrades.Count == sisUsersMissingFromLms.Count) && lmsGrades.Count == 0},{sisGrades.Count == 0}");
                }
                catch(Exception e)
                {
                    fileLines.Add($"ERROR: {entityCode}: {e.Message} {e.InnerException}");
                }
            }

            File.WriteAllLines(filePath,fileLines);
        }
        private List<string> CalculateLmsUsersMissingFromSis(List<SystemGrade> sisGrades, List<SystemGrade> lmsGrades)
        {
            Console.WriteLine($"Calculating Lms Users Not In Sis");
            List<string> lmsUsersWithoutSisUser = lmsGrades
                .Where(lmsGrade => sisGrades.All(sisGrade => sisGrade.UserINumber != lmsGrade.UserINumber)).Select(x => x.UserINumber).ToList();
            Console.WriteLine($"\tThere are {lmsUsersWithoutSisUser.Count} LMS users not in the SIS");
            return lmsUsersWithoutSisUser;
        }

        private List<string> CalculateSisUsersMissingFromLms(List<SystemGrade> sisGrades, List<SystemGrade> lmsGrades)
        {
            Console.WriteLine($"Calculating Sis Users Not In LMS");
            List<string> sisUsersWithoutLmsUser = sisGrades
                .Where(sisGrade => lmsGrades.All(lmsGrade => sisGrade.UserINumber != lmsGrade.UserINumber)).Select(x=>x.UserINumber).ToList();
            Console.WriteLine($"\tThere are {sisUsersWithoutLmsUser.Count} SIS users not in the LMS");
            return sisUsersWithoutLmsUser;
        }

        private async Task UpdateEmailTemplate(string systemName,string templateName,EmailTemplate template)
        {
            var updateEmailTemplate = _lmsDataClient.UpdateEmailTemplate(systemName,templateName,template);
        }

        public async Task GetEmailTemplatesBySystem(string systemName)
        {
            try
            {
                var emailTemplates = await _lmsDataClient.GetEmailTemplatesBySystem(systemName);
            }
            catch { }
        }
        public async Task SetFinalGrades(List<SystemGrade> grades, string submitterINumber)
        {
            try
            {
                var finalGradesSet = await _lmsDataClient.SetFinalGrades(
                    grades,
                    submitterINumber
                );
            }
            catch { }
        }

        public async Task GetLmsEntityFromCode(string entityCode)
        {
            try
            {
                var entity = await _lmsDataClient.GetLmsEntityFromCode(entityCode);
            }
            catch
            {
            }
        }

        public async Task GetSemesterForSection(string entityCode)
        {
            try
            {
                var semesterForSection = await _lmsDataClient.GetSemesterForSection(entityCode);
            }
            catch
            {
            }
        }

        public async Task GetSisEnrollmentsFromINumber(string iNumber, List<string> roles)
        {
            try
            {
                var sisEnrollments = await _lmsDataClient.GetSisEnrollmentsFromINumber(
                    iNumber,
                    roles
                );
            }
            catch
            {
            }
        }

        public async Task GetValidGradesForSection(string entityCode)
        {
            try
            {
                var validGradesSection = await _lmsDataClient.GetValidGradesForSection(entityCode);
            }
            catch
            {
            }
        }

        public async Task GetUserFromINumber(string iNumber)
        {
            try
            {
                var user = await _lmsDataClient.GetUserFromINumber(iNumber);
            }
            catch
            {
            }
        }

        public async Task<List<SystemGrade>> GetLmsFinalGrades(string entityCode)
        {
            List<SystemGrade> lmsFinalGrades = new List<SystemGrade>();
            try
            {
                Console.WriteLine($"Getting lms grades for {entityCode}"); //TODO get updated...
               // var lmsFinalGradesResponse = await _lmsDataClient.GetLmsFinalGrade(entityCode);
              //  lmsFinalGrades = lmsFinalGradesResponse.Data;
              //  Console.WriteLine($"\tGrade Count: {lmsFinalGrades.Count}");
            }
            catch
            {
            }

            return lmsFinalGrades;
        }

        public async Task<List<SystemGrade>> GetSisFinalGrades(string entityCode)
        {
            List<SystemGrade> sisFinalGrades = new List<SystemGrade>();
            try
            {
                Console.WriteLine($"Getting sis grades for {entityCode}");
                var sisFinalGradesResponse = await _lmsDataClient.GetFinalGrades(entityCode);
                sisFinalGrades = sisFinalGradesResponse.Data;
                Console.WriteLine($"\tGrade Count: {sisFinalGrades.Count} ");
            }
            catch
            {
            }

            return sisFinalGrades;
        }
    }
}
