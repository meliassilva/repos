﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using Byui.LmsClients.LmsDataClient;
using Byui.LmsClients.LmsDataClient.Interfaces;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;

namespace Byui.LMSDataBridges.Business.Business
{
    public class UserCacheBusiness
    {
        private const int BATCH_SIZE = 3000;
        private readonly ILmsDataClient _lmsDataClient;
        public UserCacheBusiness(ILmsDataClient lmsDataClient)
        {
            _lmsDataClient = lmsDataClient;
        }

        public async Task<Response<ChangeReport<User>>> CacheUsers()
        {
            var response = new Response<ChangeReport<User>> {Data = new ChangeReport<User>()};

            try
            {
                Console.WriteLine($"Getting Users");
                var userResponse = GetUsers();
                if (!userResponse.Errors.Any())
                {
                    var users = userResponse.Data;

                    var batchUsers = new List<User>();
                    var batchNumber = 0;

                    do
                    {
                        try
                        {
                            batchUsers = users.Skip(batchNumber++ * BATCH_SIZE).Take(BATCH_SIZE).ToList();
                            batchUsers.ForEach(x=>x.SystemId = String.IsNullOrEmpty(x.SystemId) ? x.UserINumber : x.SystemId);
                            Console.WriteLine($"Evaluating batch of {batchUsers.Count} users {(batchNumber-1) * BATCH_SIZE} evaluated of {users.Count}");
                            batchUsers = batchUsers.Where(x => !String.IsNullOrEmpty(x.UserINumber)).ToList();
                            ////TODO implement if needed
                            //Response<ChangeReport<User>> updateResult = _lmsDataClient.CreateOrUpdateeUsers(batchUsers).Result;
                            //response.Data.Added.AddRange(updateResult.Data.Added); //TODO this should all be moved as a add function to the change report some day
                            //response.Data.Updated.AddRange(updateResult.Data.Updated);
                            //response.Data.Deleted.AddRange(updateResult.Data.Deleted);

                            //if (updateResult.Errors.Any())
                            //{
                            //    updateResult.Errors.ForEach(Console.WriteLine);
                            //    response.Errors.AddRange(updateResult.Errors);
                            //}
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine($"{e.Message} {e.InnerException}");
                            response.Errors.Add(e.Message);
                        }
                    } while (batchUsers.Any());
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e.Message}  {e.InnerException}");
                response.Errors.Add(e.Message);
            }

            return response;
        }

        private Response<List<User>> GetUsers()
        {
            var response = new Response<List<User>>();

            try
            {
                response = _lmsDataClient.GetSisUsers(false).Result;
            }
            catch (Exception e)
            {
                response.Errors.Add(e.Message);
            }

            return response;
        }
    }
}
