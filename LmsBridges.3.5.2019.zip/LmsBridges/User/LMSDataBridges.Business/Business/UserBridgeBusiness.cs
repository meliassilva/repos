﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Byui.LmsClients.LmsDataClient;
using Byui.LMSDataBridges.Business.Interfaces;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using MoreLinq;

namespace Byui.LMSDataBridges.Business.Business
{
    public class UserBridgeBusiness : IBridgeBusiness
    {

        private LmsDataClient _lmsClient;

        public UserBridgeBusiness(LmsDataClient lmsClient)
        {
            _lmsClient = lmsClient;
        }
        public async Task RunBridge()
        {
            var sisUsersResponse = await _lmsClient.GetSisUsers();
            var lmsUsersResponse = await _lmsClient.GetUsers();
            //TODO add some error checking
            var sisUsers = sisUsersResponse.Data;
            sisUsers = sisUsers.Where(x=>x.UserINumber != null).DistinctBy(x => x.UserINumber).ToList();
            var sisUsersDict = sisUsers.ToDictionary(x => x.UserINumber, x => x);

            var lmsUsers = lmsUsersResponse.Data;
            
            var lmsSystems = lmsUsers.Select(x => x.SystemName).Distinct();

            foreach (var lmsSystem in lmsSystems)
            {
                var lmsSystemUsers = lmsUsers.Where(x => x.SystemName == lmsSystem).ToList();
                lmsSystemUsers = lmsSystemUsers.Where(x => x.UserINumber != null).DistinctBy(x => x.UserINumber).ToList();
                var lmsUserDict = lmsSystemUsers.ToDictionary(x => x.UserINumber, x => x);

                var missingLmsUsers = sisUsers.Where(user => !lmsUserDict.ContainsKey(user.UserINumber)).ToList();
                if (lmsSystem.ToLower() == "canvas")
                {
                    missingLmsUsers = missingLmsUsers.Where(user => user.SystemName.ToLower() != "icecrm").ToList();
                }

                var daUpdate = await _lmsClient.CreateOrUpdateUsers(missingLmsUsers,lmsSystem);
                Console.WriteLine($"{missingLmsUsers.Count} missing users in {lmsSystem}");
            }

            Console.WriteLine($"{sisUsers.Count} {lmsUsers.Count}");
        }
    }
}
