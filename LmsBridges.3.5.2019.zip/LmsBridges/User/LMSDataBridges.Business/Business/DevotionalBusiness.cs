﻿using Byui.LMSDataBridges.Enterprise.Interfaces;
using Byui.LmsData.CommonObjects;
using Byui.LmsData.CommonObjects.Objects;
using Flurl;
using Flurl.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Byui.LmsClients.LmsDataClient;
using Byui.LMSDataBridges.Business.Interfaces;
using Byui.LMSDataBridges.Business.Utilities;
using MoreLinq;

namespace Byui.LMSDataBridges.Business.Business
{
    public class DevotionalBusiness : IBridgeBusiness
    {
        private readonly IServiceConfiguration _configuration;

        public DevotionalBusiness(IServiceConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Start the Devotional Enrollments Bridge (DEB)
        /// </summary>
        /// <returns></returns>
        public async Task RunBridge()
        {
            //Empty lists instantiation
            Console.WriteLine($"#############   Devotional Enrollments Bridge  ###############\n");
            List<Exception> errorsRunningDevotionalBridge = new List<Exception>();

            //Canvas base URL
            var _canvasUrlBeta = "https://byui.beta.instructure.com";
            var _canvasUrl = "https://byui.instructure.com";

            try
            {
                ////Remote Conneciton
               // LmsDataClient lmsDataClient = new LmsDataClient(_configuration.LmsDataClientId, _configuration.LmsDataClientSecret);

                //Local
                LmsDataClient lmsDataClient = new LmsDataClient(56665);

                //Get current or next semester
                string semesterCode = await GetSemesterToWork(lmsDataClient);
                Console.WriteLine($" - Running for {semesterCode} Semester");

                //Current Devotional Course Name
                var devotionalCourseCode = $"{semesterCode}.Devotional";

                //Get Active User Enrolled by Semester Code
                var enrollmentsCurrentSemesterResponse = await lmsDataClient.GetSisUsersFromSemesterCode(semesterCode,LmsData.CommonObjects.Enums.System.Cx,true);

                //Exclude the LDSBusiness College students
                var enrollmentsCurrentSemester = enrollmentsCurrentSemesterResponse.Data;
                    enrollmentsCurrentSemester = enrollmentsCurrentSemester
                    .Where(enrollment => enrollment.SystemName.ToLower() != "icecrm").ToList();


                var existingLmsDevotionalCourseEnrollmentsResponse = await
                    lmsDataClient.GetLmsEnrollmentsFromEntity(devotionalCourseCode);//TODO need to add false flag


                var existingLmsDevotionalCourseEnrollments = existingLmsDevotionalCourseEnrollmentsResponse.Data;
                var missingEnrollments = enrollmentsCurrentSemester.Where(enrollment =>
                    existingLmsDevotionalCourseEnrollments.All(lmsEnrollment =>
                    lmsEnrollment.UserINumber != enrollment.UserINumber)).ToList();

                var allowedTeachers = new List<string> {"083260840", "684528834", "309096135"}; //Trish Gannaway, Rebekah Griffin, and Benjamin Yates 
                //var rougeInstructorEnrollments = existingLmsDevotionalCourseEnrollments
                //    .Where(x => x.RoleName.ToLower() != "student").Where(x=>!allowedTeachers.Contains(x.UserINumber)).ToList();

                //var deleteRequests = rougeInstructorEnrollments.Select(x => new EnrollmentRequest
                //{
                //    INumber = x.UserINumber,
                //    RoleName = "Teacher",
                //    SectionCode = devotionalCourseCode
                //}).Where(x=>x.INumber != null).ToList();
                //var deleteThem = await lmsDataClient.DeleteLmsEnrollments(deleteRequests);
                Console.WriteLine($"are the gone yet?");
                //Looping through active users and create a new list of enrolmentRequest objects
                List<EnrollmentRequest> enrollmentRequests = missingEnrollments.Select(missingEnrollment => new EnrollmentRequest
                {
                    INumber = missingEnrollment.UserINumber,
                    RoleName = "Student",
                    SectionCode = devotionalCourseCode
                }).ToList();

                WriteEnrollmentRequestsToFile(enrollmentRequests,lmsDataClient);

                //Post enrollments on CANVAS
               // enrollmentRequests = enrollmentRequests.Take(500).ToList(); //TODO erase after we are happy

                var enrollmentResult = await CreateDevotionalCourseEnrollments(lmsDataClient,enrollmentRequests);
                Console.WriteLine($"How fun was that?");
            }
            catch (Exception e)
            {
                errorsRunningDevotionalBridge.Add(e);
            }
        }

        private static void WriteEnrollmentRequestsToFile(List<EnrollmentRequest> enrollmentRequests, LmsDataClient lmsDataClient)
        {
            var users = lmsDataClient.GetUsers().Result;
            var canvasUsers = users.Data.Where(x => x.SystemName.ToLower() == "canvas").ToList();
            canvasUsers = canvasUsers.Where(x => !string.IsNullOrEmpty(x.UserINumber)).ToList();
            canvasUsers = canvasUsers.DistinctBy(x => x.UserINumber).ToList();
            var canvasUserDict = canvasUsers.ToDictionary(x => x.UserINumber, x => x);

            var requestsWithMissingUsers = enrollmentRequests.Where(x => !canvasUserDict.ContainsKey(x.INumber)).ToList();
            Console.WriteLine($"{requestsWithMissingUsers.Count} requests do not have Canvas users");
            var requestsWithoutMissingUsers = enrollmentRequests.Where(x => canvasUserDict.ContainsKey(x.INumber)).ToList();
            
            var enrollmentFileContents = $"course_id,user_id,role,section_id,status{System.Environment.NewLine}";
            foreach (var enrollmentRequest in requestsWithoutMissingUsers)
            {
                enrollmentFileContents +=
                    $"36714,{ canvasUserDict[enrollmentRequest.INumber].SystemId},{enrollmentRequest.RoleName},28888,active{System.Environment.NewLine}";
            }

            File.WriteAllText("missing-devotional-enrollments-winter-2019.csv", enrollmentFileContents);

            var littleEnrollmentFileContents = $"course_id,user_id,role,section_id,status{System.Environment.NewLine}";
            var littleRequestsWithoutMissingUsers = requestsWithoutMissingUsers.Take(15).ToList();
            foreach (var enrollmentRequest in littleRequestsWithoutMissingUsers)
            {
                littleEnrollmentFileContents +=
                    $"36714,{ canvasUserDict[enrollmentRequest.INumber].SystemId},{enrollmentRequest.RoleName},28888,active{System.Environment.NewLine}";
            }

            File.WriteAllText("missing-devotional-enrollments-winter-2019-try-me.csv", littleEnrollmentFileContents);
        }

        private async Task<object> CreateDevotionalCourseEnrollments(LmsDataClient lmsDataClient, List<EnrollmentRequest> enrollmentRequests)
        {
            var batchSize = 100;
            var enrollmentsQueue = new Queue<EnrollmentRequest>(enrollmentRequests);
            while (enrollmentsQueue.Any())
            {
                Console.WriteLine($"Processing batch of {batchSize}... There are {enrollmentsQueue.Count} remaining.");
                var nextBatch = enrollmentsQueue.Dequeue(batchSize);
                foreach (var enrollmentRequest in nextBatch)
                {
                    try
                    {
                        if (await EnsureUserExistsInCanvas(lmsDataClient, enrollmentRequest)) continue;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine($"{e.Message}");
                    }
                }

                var enrollmentsResult = await lmsDataClient.CreateOrUpdateLmsEnrollments(nextBatch);
            }

            return true;
        }

        private static async Task<bool> EnsureUserExistsInCanvas(LmsDataClient lmsDataClient, EnrollmentRequest enrollmentRequest)
        {
            Response<List<User>> userResponse = await lmsDataClient.GetUserFromINumber(enrollmentRequest.INumber);
            if (userResponse.Data == null)
            {
                return true;
            }

            var canvasUser = userResponse.Data.FirstOrDefault(x => x.SystemName.ToLower() == "canvas");
            if (canvasUser == null)
            {
                Response<List<User>> sisUserResponse =
                    await lmsDataClient.GetSisUserFromINumber(enrollmentRequest.INumber);
                if (sisUserResponse.Data != null && !sisUserResponse.Errors.Any())
                {
                    var user = sisUserResponse.Data.FirstOrDefault();
                    Console.WriteLine($"Creating user {user.UserINumber} {user.UserFirst} {user.UserLast} {user.UserLogin} {user.UserEmail}");
                    var userCreateResponse =
                        await lmsDataClient.CreateOrUpdateUsers(new List<User>
                        {
                            user
                        },"Canvas");
                }
            }

            return false;
        }

        /// <summary>
        /// Get current or next semester
        /// </summary>
        /// <param name="lmsClients"></param>
        /// <returns></returns>
        
        private async Task<string> GetSemesterToWork(LmsDataClient lmsClients)
        {
            //Get current semester based on datatime.now
            var currentSemester = await lmsClients.GetCurrentSemester();

            //Get next semester based on datatime.now
            var nextSemester = await lmsClients.GetNextSemester();

            //Convert the semester Code to Current or Next based on the datetime.now
            return DateTime.Now > currentSemester.Data.EndDate ? ConvertToSemesterCode(nextSemester) : ConvertToSemesterCode(currentSemester);
        }

        /// <summary>
        /// Convert the object Semester from getSemester (LmsDataClient) to semesterCode
        /// </summary>
        /// <param name="semester"></param>
        /// <returns>(e,g 2018.Spring)</returns>
        
        private string ConvertToSemesterCode(Response<Semester> semester)
        {
            var result = "";
            var _year = semester.Data.Name.Split(" ").LastOrDefault();
            var _sessionName = semester.Data.Name.Substring(0, semester.Data.Name.IndexOf(" "));
            result = $"{_year}.{_sessionName}";
            return result;
        }

        /// <summary>
        /// Post Enrollment on Canvas
        /// </summary>
        /// <param name="enrollmentsRequest"></param>
        /// <param name="lmsDataClient"></param>
        /// <param name="devotionalCourseName"></param>
        /// <param name="canvasUrl"></param>
        /// <returns></returns>

//TODO move to LmsData

        public async Task<Response<ChangeReport<Enrollment>>> PostEnrollments(List<EnrollmentRequest> enrollmentsRequest, LmsDataClient lmsDataClient, string devotionalCourseName, string canvasUrl)
        {
            var errors = new List<string>();
            var failed = new List<EnrollmentRequest>();
            StringContent content = GetHttpContent();

            foreach (var enrollmentRequest in enrollmentsRequest)
            {
                var userResponse = await lmsDataClient.GetUserFromINumber(enrollmentRequest.INumber);

                try
                {
                    var roleName = enrollmentRequest.RoleName.ToUpper() == "STUDENT" ? "StudentEnrollment" : "TeacherEnrollment";
                    var status = "active";

                    foreach (var userId in userResponse.Data)
                    {
                        if (userId.SystemName.ToUpper() == "CANVAS")
                        {
                            new Url($"{canvasUrl}/api/v1/courses/sis_course_id:{devotionalCourseName}/enrollments").SetQueryParams(new Dictionary<string, string>
                        {
                            { "enrollment[user_id]", userId.SystemId },
                            { "enrollment[type]", roleName },
                            { "enrollment[enrollment_state]", status }
                        });
                            await new Url($"{canvasUrl}/api/v1/courses/sis_course_id:{devotionalCourseName}/enrollments").WithOAuthBearerToken(_configuration.CanvasToken).PostAsync(GetHttpContent());
                        }
                    }
                }
                catch (Exception ex)
                {
                    failed.Add(enrollmentRequest);
                    errors.Add(ex.Message);
                }
            }

            return new Response<ChangeReport<Enrollment>>
            {
                Data = new ChangeReport<Enrollment>
                {
                    ////TODO differ between added, updated, and deleted
                    //Added = enrollmentRequest
                },

                Errors = errors
            };
        }
        
        /// <summary>
        /// Useful for post enrollments
        /// </summary>
        /// <returns></returns>
        private static StringContent GetHttpContent() => new StringContent("{}");
    }
}