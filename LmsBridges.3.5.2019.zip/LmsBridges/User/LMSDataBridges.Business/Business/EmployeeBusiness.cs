﻿using Byui.LMSDataBridges.Enterprise.Interfaces;
using Byui.LmsData.CommonObjects.Objects;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Byui.LmsClients.LmsDataClient;
using Byui.LMSDataBridges.Business.Interfaces;

namespace Byui.LMSDataBridges.Business.Business
{
    public class EmployeeBusiness : IBridgeBusiness
    {
        private readonly IServiceConfiguration _configuration;
        public EmployeeBusiness(IServiceConfiguration configuration)
        {
            _configuration = configuration;
        }
        public async Task RunBridge()
        { 
            //Empty lists instantiation
            Console.WriteLine($"#############   Employee Enrollments Bridge  ###############\n");

            //Canvas base URL
            //var _canvasUrlBeta = "https://byui.beta.instructure.com";
            //var _canvasUrl = "https://byui.instructure.com";

            try
            {
                ////Remote Conneciton
                //LmsDataClient lmsClients = new LmsDataClient(_configuration.LmsDataClientId, _configuration.LmsDataClientSecret);
                LmsDataClient lmsDataClient = new LmsDataClient(56665);

                //Local
                List<User> employees;
                using (StreamReader r = new StreamReader(@"\\idrive\tech\Dan\CanvasIntegration\EmployeeEnrollmentBridge\JSONFile.json"))
                {
                    string json = r.ReadToEnd();
                    employees = JsonConvert.DeserializeObject<List<User>>(json);
                }
                string status = "Active";
                string role = "Participant";
                string id = "19004";
                using (StreamWriter w = new StreamWriter(@"\\idrive\tech\Dan\CanvasIntegration\EmployeeEnrollmentBridge\ecsvfile.csv"))
                {
                    w.WriteLine("course_id,user_id,role,status");
                    foreach (User item in employees)
                    {
                        w.WriteLine(id + "," + item.UserINumber + "," + role + "," + status);
                    }
                }

                var existingEnrollmentsResponse = await lmsDataClient.GetLmsEnrollmentsFromEntity("Employee.Discussion.Board");
                var existingEnrollments = existingEnrollmentsResponse.Data;

                //Looping through active users and create a new list of enrolmentRequest objects
                var enrollmentRequests = employees.Select(missingEnrollment => new EnrollmentRequest
                {
                    INumber = missingEnrollment.UserINumber,
                    RoleName = "Student",
                    SectionCode = "Employee.Discussion.Board"
                }).ToList();

                enrollmentRequests = enrollmentRequests
                    .Where(x => existingEnrollments.All(y => x.INumber != y.UserINumber)).ToList();
                //Post enrollments on CANVAS
                //enrollmentRequests = enrollmentRequests.Take(14).ToList();
                var enrollmentResult = await lmsDataClient.CreateOrUpdateLmsEnrollments(enrollmentRequests);
            }
            catch (Exception e)
            {
                
            }
        }
    }
}
