﻿namespace Byui.LMSDataBridges.Business.Test
{
    /// <summary>
    /// 
    /// </summary>
    public class AppSettings
    {
        /// <summary>
        /// ServiceUser
        /// </summary>
        public string ServiceUser { get; set; }

        /// <summary>
        /// ServicePassword
        /// </summary>
        public string ServicePassword { get; set; }

        /// <summary>
        /// MetadataAddress
        /// </summary>
        public string MetadataAddress { get; set; }
        
        /// <summary>
        /// ConnectionString
        /// </summary>
        public string ConnectionString { get; set; }
        
        /// <summary>
        /// SoaDomain
        /// </summary>
        public string SoaDomain { get; set; }
        public string CanvasToken { get; set; }
    }
}
