﻿using System;
using Byui.LMSDataBridges.Business.Business;
using Byui.LMSDataBridges.Business.Entities;
using Byui.LMSDataBridges.Business.Utilities;
using Byui.LMSDataBridges.Enterprise.Configuration;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using Byui.LMSDataBridges.Enterprise.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;


namespace Byui.LMSDataBridges.Business.Test
{
    public class TemplateFixture : IDisposable
    {

        public readonly IServiceProvider ServiceProvider;
        private const bool UseInMemoryDatabase = true;

        public TemplateFixture()
        {
            var builder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddUserSecrets<TemplateFixture>();

            IConfigurationRoot config = builder.Build();

            var services = new ServiceCollection();

            AppSettings appSettings = new AppSettings
            {
                ServiceUser = config["lmsDataClientId"],
                ServicePassword = config["lmsDataClientSecret"],
                CanvasToken = config["CanvasToken"]
            };
            config.GetSection("AppSettings").Bind(appSettings);
            services.AddSingleton(appSettings);
            
            //TODO I don't think this is anywhere close to correct
            IServiceConfiguration configuration = new ServiceConfiguration("","",
                appSettings.ServiceUser,
                appSettings.ServicePassword,
                appSettings.ConnectionString,
                appSettings.ConnectionString,//TODO this should be the bridge monitor url
                appSettings.MetadataAddress,
                appSettings.SoaDomain,
                appSettings.CanvasToken,
                appSettings.SoaDomain,
                120
            );

            services.AddSingleton(configuration);

            // ReSharper disable once ConditionIsAlwaysTrueOrFalse
            if (UseInMemoryDatabase)
            {
                services.AddDbContext<LMSDataBridgesContext>(options => options.UseInMemoryDatabase());
                // Configure Automapper and dependancy injection
                Configuration.Configure(services,configuration);
            }
            else
            {
                // Configure Automapper and dependancy injection
                Configuration.Configure(services, configuration);
            }

            ServiceProvider = services.BuildServiceProvider();

            if (UseInMemoryDatabase)
            {
                Setup();
            }

        }

        /// <summary>
        /// Run to setup in memory database.
        /// </summary>
        private void Setup()
        {
            var ctx = ServiceProvider.GetService<LMSDataBridgesContext>();
        }

        public void Dispose()
        {
            
        }
    }
}
