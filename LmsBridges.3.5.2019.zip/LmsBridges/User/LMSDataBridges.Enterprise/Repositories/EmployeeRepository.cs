﻿using Byui.LMSDataBridges.Enterprise.Configuration;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Byui.LMSDataBridges.Enterprise.Repositories
{
    public class EmployeeRepository
    {
        private readonly ServiceHelper _serviceHelper;
        public EmployeeRepository(IServiceConfiguration serviceConfiguration)
        {
            _serviceHelper = new ServiceHelper(serviceConfiguration);
        }
    }
}
