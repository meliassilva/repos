﻿using Byui.LMSDataBridges.Enterprise.Configuration;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using RegistrationService;

namespace Byui.LMSDataBridges.Enterprise.Repositories
{
    public class StudentRepository
    {
        private readonly ServiceHelper _serviceHelper;
        private readonly RegistrationServiceClient _regSrvClient;

        public StudentRepository(IServiceConfiguration serviceConfiguration)
        {
            _serviceHelper = new ServiceHelper(serviceConfiguration);
            _regSrvClient = _serviceHelper.GetReadOnlyRegistrationServiceClient();
        }
    }
}
