﻿using Byui.LMSDataBridges.Enterprise.Configuration;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using RegistrationService;

namespace Byui.LMSDataBridges.Enterprise.Repositories
{
    public class TeacherRepository
    {
        private readonly ServiceHelper _serviceHelper;
        private readonly RegistrationServiceClient _regSrvClient;

        public TeacherRepository(IServiceConfiguration serviceConfiguration)
        {
            _serviceHelper = new ServiceHelper(serviceConfiguration);
            _regSrvClient = _serviceHelper.GetReadOnlyRegistrationServiceClient();
        }
    }
}