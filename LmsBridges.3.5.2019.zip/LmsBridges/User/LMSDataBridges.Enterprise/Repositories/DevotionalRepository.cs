﻿using Byui.LMSDataBridges.Enterprise.Configuration;
using Byui.LMSDataBridges.Enterprise.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Byui.LMSDataBridges.Enterprise.Repositories
{
    public class DevotionalRepository 
    {
        private readonly ServiceHelper _serviceHelper;
        public DevotionalRepository(IServiceConfiguration serviceConfiguration)
        {
            _serviceHelper = new ServiceHelper(serviceConfiguration);
        }
    }
}
