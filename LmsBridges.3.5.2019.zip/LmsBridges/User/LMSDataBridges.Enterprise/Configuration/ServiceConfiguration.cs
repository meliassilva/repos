﻿using System.Data.Common;
using Byui.LMSDataBridges.Enterprise.Interfaces;

namespace Byui.LMSDataBridges.Enterprise.Configuration
{
    public class ServiceConfiguration : IServiceConfiguration
    {
        public string ConnectionString { get; }
        public string LmsDataClientId { get;}
        public string LmsDataClientSecret { get;}
        public string ApiBaseUrl { get; }
        public int TimeoutInSeconds { get; }
        public string SoaDomain { get; }
        public string CanvasToken { get; }
        public string ServiceDomain { get; }
        public string ServiceUser { get; }
        public string ServicePassword { get; }
        public string BridgeMonitoringApiUrl { get; set; }

        public ServiceConfiguration(string connectionString,
                                    string lmsDataClientId,
                                    string lmsDataClientSecret,
                                    string apiBaseUrl,
                                    string bridgeMonitoringUrl,
                                    string serviceUser,
                                    string servicePassword,
                                    string soaDomain,
                                    string canvasToken,
                                    string serviceDomain,
                                    int timeouInSeconds
                                    )
        {
            ConnectionString = connectionString;
            LmsDataClientId = lmsDataClientId;
            LmsDataClientSecret = lmsDataClientSecret;
            ApiBaseUrl = apiBaseUrl;
            BridgeMonitoringApiUrl = bridgeMonitoringUrl;
            TimeoutInSeconds = timeouInSeconds;
            SoaDomain = soaDomain;
            CanvasToken = canvasToken;
            ServiceDomain = serviceDomain;
            ServiceUser = serviceUser;
            ServicePassword = servicePassword;
        }

    }
}
