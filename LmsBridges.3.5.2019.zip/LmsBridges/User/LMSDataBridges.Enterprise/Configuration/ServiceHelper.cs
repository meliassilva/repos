﻿using Byui.LMSDataBridges.Enterprise.Interfaces;
using RegistrationService;
using System;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace Byui.LMSDataBridges.Enterprise.Configuration
{
    public class ServiceHelper
    {
        //// -- READ ONLY END POINTS SHOULD BE USED ALWAYS UNLESS YOU NEED TO UPDATE DATA
        private const string READ_ONLY_PERSON_SERVICE_QA = "https://soaqa.byui.edu/PersonManagement.Service.v6/PersonServiceReadOnly.svc/http";
        private const string READ_ONLY_PERSON_SERVICE_PROD = "https://soa.byui.edu/PersonManagement.Service.v6/PersonServiceReadOnly.svc/http";

        private const string READ_ONLY_REGISTRATION_SERVICE_QA = "https://soaqa.byui.edu/Registration.Service.v6/RegistrationServiceReadOnly.svc/http";
        private const string READ_ONLY_REGISTRATION_SERVICE_PROD = "https://soa.byui.edu/Registration.Service.v6/RegistrationServiceReadOnly.svc/http";

        //// -- Non Read Only
        private const string PERSON_SERVICE_QA = "https://soaqa.byui.edu/PersonManagement.Service.v6/PersonService.svc/http";
        private const string PERSON_SERVICE_PROD = "https://soa.byui.edu/PersonManagement.Service.v6/PersonService.svc/http";

        private const string REGISTRATION_SERVICE_QA = "https://soaqa.byui.edu/Registration.Service.v6/RegistrationService.svc/http";
        private const string REGISTRATION_SERVICE_PROD = "https://soa.byui.edu/Registration.Service.v6/RegistrationService.svc/http";

        //// TODO add the other services here
        //private const string WARDS_AND_STAKES_SERVICE_QA = "net.tcp://soaqa.byui.edu/WardsAndStakes.Service/WardsAndStakesService.svc/tcpService";
        //private const string WARDS_AND_STAKES_SERVICE_PROD = "net.tcp://soa.byui.edu/WardsAndStakes.Service/WardsAndStakesService.svc/tcpService";

        //private const string UTILITIES_SERVICE_QA = "net.tcp://soaqa.byui.edu/Utilities.Service/UtilitiesService.svc/tcpService";
        //private const string UTILITIES_SERVICE_PROD = "net.tcp://soa.byui.edu/Utilities.Service/UtilitiesService.svc/tcpService";

        private const string IdentityManagementServiceDevAddress = "https://soaqa.byui.edu/identitymanagement.service/identitymanagement.svc/http";
        private const string IdentityManagementServiceProdAddress = "https://soa.byui.edu/identitymanagement.service/identitymanagement.svc/http";
        //private const string IdentityManagementServiceDevAddress = "net.tcp://soaqa.byui.edu/identitymanagement.service/identitymanagement.svc/tcpService";
        //private const string IdentityManagementServiceProdAddress = "net.tcp://soa.byui.edu/identitymanagement.service/identitymanagement.svc/tcpService";

        private readonly IServiceConfiguration _configuration;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="configuration"></param>
        public ServiceHelper(IServiceConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Gets the NetworkCredential to use with the endpoints.
        /// </summary>
        /// <returns></returns>
        private NetworkCredential GetCredential()
        {
            return new NetworkCredential(_configuration.ServiceUser, _configuration.ServicePassword, _configuration.ServiceDomain);
        }

        ///// <summary>
        ///// Gets a binding for use with the web services.
        ///// </summary>
        ///// <returns></returns>
        private BasicHttpBinding GetBinding()
        {
            BasicHttpBinding binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport)
            {
                CloseTimeout = TimeSpan.FromSeconds(_configuration.TimeoutInSeconds),
                OpenTimeout = TimeSpan.FromSeconds(_configuration.TimeoutInSeconds),
                SendTimeout = TimeSpan.FromSeconds(_configuration.TimeoutInSeconds),
                ReceiveTimeout = TimeSpan.FromSeconds(_configuration.TimeoutInSeconds)
            };
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            binding.MaxReceivedMessageSize = int.MaxValue;
            binding.MaxBufferSize = int.MaxValue;

            return binding;
        }

        ///// <summary>
        ///// Process when a service channel faults, this way it can still be disposed.
        ///// </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        private void InnerChannel_Faulted(object sender, EventArgs e)
        {
            //make sure the channel is aborted
            (sender as ICommunicationObject).Abort();
        }

        /// <summary>
        /// Increases the object graph size per operation and timeout per operation.  This can be called in order to allow for some SOA methods that
        /// take longer to run.
        /// </summary>
        /// <param name="endpoint"></param>
        /// <param name="channel"></param>
        /// <param name="timeoutInMinutes"></param>
        public static void IncreaseObjectGraphSizeAndOperationTimeout(ServiceEndpoint endpoint, IClientChannel channel, int timeoutInMinutes = 2)
        {
            channel.OperationTimeout = TimeSpan.FromMinutes(timeoutInMinutes);

            foreach (OperationDescription operation in endpoint.Contract.Operations)
            {
                DataContractSerializerOperationBehavior behavior = operation.OperationBehaviors.FirstOrDefault(o => o is DataContractSerializerOperationBehavior) as DataContractSerializerOperationBehavior;
                if (behavior != null)
                {
                    behavior.MaxItemsInObjectGraph = int.MaxValue;
                }
            }
        }

        ///// <summary>
        ///// Gets a read only person service client.
        ///// </summary>
        ///// <returns></returns>
        //public PersonServiceClient GetReadOnlyPersonServiceClient()
        //{
        //    return GetPersonServiceClient(false);
        //}

        /////// <summary>
        /////// Gets a writable person service client.
        /////// </summary>
        /////// <returns></returns>
        ////public PersonServiceClient GetPersonServiceClient()
        ////{
        ////    return GetPersonServiceClient(true);
        ////}

        public RegistrationServiceClient GetReadOnlyRegistrationServiceClient()
        {
            return GetRegistrationServiceClient(false);
        }

        ///// <summary>
        ///// Gets a person service client.
        ///// </summary>
        ///// <returns></returns>
        //        private PersonServiceClient GetPersonServiceClient(bool isWritable)
        //        {
        //            PersonServiceClient serviceClient;
        //            var binding = GetBinding();
        //            serviceClient = new PersonServiceClient(binding,
        //                new EndpointAddress(isWritable ? string.Format(PersonService, _configuration.SoaDomain) 
        //                    : string.Format(ReadOnlyPersonService, _configuration.SoaDomain)));
        //            
        //
        //            serviceClient.ClientCredentials.UserName.UserName = $"{_configuration.ServiceDomain}\\{_configuration.ServiceUser}";
        //            serviceClient.ClientCredentials.UserName.Password = _configuration.ServicePassword;
        //            (serviceClient as ICommunicationObject).Faulted += InnerChannel_Faulted;
        //
        //            return serviceClient;
        //        }

        /// <summary>
        /// Gets a Registration Service client.
        /// </summary>
        /// <param name="isWritable"></param>
        /// <returns></returns>
        private RegistrationServiceClient GetRegistrationServiceClient(bool isWritable)
        {
            RegistrationServiceClient serviceClient;
            var binding = GetBinding();

            serviceClient = new RegistrationServiceClient(binding,
               new EndpointAddress(isWritable ? REGISTRATION_SERVICE_PROD : READ_ONLY_REGISTRATION_SERVICE_PROD));

            serviceClient.ClientCredentials.UserName.UserName = $"{_configuration.ServiceDomain}\\{_configuration.ServiceUser}";
            serviceClient.ClientCredentials.UserName.Password = _configuration.ServicePassword;
            (serviceClient as ICommunicationObject).Faulted += InnerChannel_Faulted;

            return serviceClient;
        }
    }
}
