﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Byui.LMSDataBridges.Enterprise.Interfaces
{
    public interface IBridgesRepository
    {
        Task RunBridge();
    }
}
