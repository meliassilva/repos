﻿using System;

namespace Byui.LMSDataBridges.Enterprise.Interfaces
{
    /// <summary>
    /// Provides the needed information in order to configure and use enterprise web services.
    /// </summary>
    public interface IServiceConfiguration
    {
        string ConnectionString { get; }
        string LmsDataClientId { get;}
        string LmsDataClientSecret { get;}
        string ApiBaseUrl { get; }
        int TimeoutInSeconds { get; }
        string SoaDomain { get; }
        string CanvasToken { get; }
        string ServiceDomain { get; }
        string ServiceUser { get; }
        string ServicePassword { get; }
        string BridgeMonitoringApiUrl { get; set; }
    }
}
