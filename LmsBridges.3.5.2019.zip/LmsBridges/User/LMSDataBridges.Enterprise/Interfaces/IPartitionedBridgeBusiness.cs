﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Byui.LmsData.CommonObjects;
using RegistrationService;

namespace Byui.LMSDataBridges.Enterprise.Interfaces
{
    public interface IPartitionedBridgeBusiness<T>
    {
        Task<Response<ChangeReport<T>>> RunBridge(string runId);
    }
}
