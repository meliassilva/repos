﻿namespace Byui.LMSDataBridges.Enterprise.Interfaces
{
    public interface ITeacherBusiness 
    {
        //async Task RunTeacherEnrollmentsAsync();
    }
}