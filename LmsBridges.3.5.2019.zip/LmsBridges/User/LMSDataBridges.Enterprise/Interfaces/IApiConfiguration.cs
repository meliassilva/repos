﻿namespace Byui.LMSDataBridges.Enterprise.Interfaces
{
    public interface IApiConfiguration
    {

        string ApiBaseUrl { get; set; }
        string ApiKey { get; set; }
        string ApiSecret { get; set; }
    }
}
